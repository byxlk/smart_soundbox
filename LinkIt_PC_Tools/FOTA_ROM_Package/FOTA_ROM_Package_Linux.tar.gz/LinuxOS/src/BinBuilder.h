#include <iostream>
#include <string>
#include <vector>
#include "BinBuilder_error.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "sha1.h"
#ifdef __cplusplus
}
#endif

//#define DEBUG

#define MAX_BUFFER_SIZE (1 << 24)  // 4MB,
#define BIN_NUMBER 4  // origin 16
#define MAX_FILE_NAME_LEN 256
#define MAX_SEC_NAME_LEN BIN_NUMBER * 30
#define SHA1_HASH_CODE_LEN 20
#define MAX_OUT_BUFFER_SIZE (MAX_BUFFER_SIZE * 4)

using namespace std;
typedef int S32;
typedef unsigned char U8;
typedef unsigned short U16;
typedef unsigned int U32;

// FOTA pkg layout
/**
  *----------start-------------
  * IOT_FOTA_HEADER                |
  *---------------------------
  * header sha1 hash                   |
  *---------------------------
  * #1 BIN content                       |
  *---------------------------
  * #1 BIN sha1 hash                   |
  *---------------------------
  * #2 BIN content                       |
  *---------------------------
  * #2 BIN sha1 hash                   |
  *---------------------------
  *                   ......                     |
  *-----------end-------------
  */

typedef struct {
    /* version of structure */
    S32 m_ver;
    /* update information for DM */
    S32 m_error_code;
    /* the behavior of bootloader for this error */
    S32 m_behavior;
    /* check if DM has read */
    S32 m_is_read;
    /* marker for power loss recovery, 32 is FUNET_MARKER_REGION_SIZE */
    char m_marker[32];
    /* reserved & make the structure 64 bytes */
    S32 reserved[4];
} IOT_FOTA_UPDATE_INFO;

typedef struct {
    /* bin offset from FOTA pkg head */
    U32 m_bin_offset;
    /* bin start addr in ROM */
    U32 m_bin_start_addr;
    /* bin length */
    U32 m_bin_length;
    /* partition size */
    U32 m_partition_length;
    /* sig offset from FOTA pkg head*/
    U32 m_sig_offset;
    /* sig length */
    U32 m_sig_lenth;
    /* is compressed or not */
    U32 m_is_compressed;
    /* reserved fields */
    U8 m_bin_reserved[4];
} IOT_BIN_INFO;

typedef struct {
    U32 m_magic_ver;
    U32 m_bin_num;
    IOT_BIN_INFO m_extra_info[4];
} IOT_FOTA_HEADER;

class bin_info_t {
   public:
    bin_info_t &operator=(const bin_info_t &other) {
        if (this != &other) {
            filePath = other.filePath;
            start_addr = other.start_addr;
            isCompressed = other.isCompressed;
        }
        return *this;
    }

    string filePath;
    unsigned int start_addr;
    unsigned int partition_size;
    int isCompressed;

    friend ostream &operator<<(ostream &os, const bin_info_t &dt);
};

class BinBuilder {
   public:
    BinBuilder(void);
    ~BinBuilder(void);

    int GenerateNewBin(vector<bin_info_t> *bins, const wstring &configFile);
    int GetAllBinsInINIFile(vector<bin_info_t> *bins,
                            const wstring &outputFile);
    IOT_FOTA_HEADER header;

   private:
    int FillHeaderInfo(U32 bin_count, U32 offset, U32 bin_pack_size,
                       U32 bin_unpack_size, bin_info_t &bin_info);
    // for lzma encode buffer
    int AllocateEncodeBuffer(char **inBuf, char **outBuf);
    int FreeEncodeBuffer(char **inBuf, char **outBuf);
};
