#ifdef _WIN32
#include <windows.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string>
#include <vector>
#include <fstream>
#include <assert.h>
#include <sys/stat.h>

#include "BinBuilder.h"

#ifdef __cplusplus
extern "C" {
#endif
#include "sha1.h"
#include "7zTypes.h"
#include "LzmaEnc.h"
#include "cJSON.h"
#ifdef __cplusplus
}
#endif

using namespace std;

static void *SzAlloc(void *p, size_t size) { return malloc(size); }
static void SzFree(void *p, void *address) { free(address); }
static ISzAlloc g_Alloc = {SzAlloc, SzFree};

static int MyGetFileSize(string s) {
#ifdef _WIN32
    HANDLE handle = CreateFileA(s.c_str(), FILE_READ_EA, FILE_SHARE_READ, 0, OPEN_EXISTING, 0, 0);
    if (handle != INVALID_HANDLE_VALUE) {
        int size = GetFileSize(handle, NULL);
        cout << size << endl;
        CloseHandle(handle);
        return size;
    }
    return -1;
#else
    struct stat st;
    stat(s.c_str(), &st);
    cout << st.st_size << endl;
    return st.st_size;
#endif
}

BinBuilder::BinBuilder(void) { memset(&header, 0, sizeof(header)); }

BinBuilder::~BinBuilder(void) {}

int BinBuilder::GenerateNewBin(vector<bin_info_t> *bins,
                               const wstring &outputFile) {
    U32 bin_count = 0;
    U32 offset = 0x00000000;
    char *buffer = NULL;
    char *out_buffer = NULL;
    char outputBin[MAX_FILE_NAME_LEN] = {0};
    unsigned char hash[SHA1_HASH_CODE_LEN] = {0};
    SHA1_CTX ctx;

    wcstombs(outputBin, &outputFile[0], MAX_FILE_NAME_LEN);
    cout << "Output File = " << outputBin << endl;

    fstream writer(outputBin, std::ios::out | std::ios_base::binary);
    if (!writer) {
        cout << endl << "cannot open output file: " << outputBin << endl;
        return E_File_OPEN_FAIL;
    }

    // shift to the beginning of the 1st bin content
    offset += sizeof(IOT_FOTA_HEADER) + SHA1_HASH_CODE_LEN;
    writer.seekp(offset);

    // load bin into buffers from dir
    vector<bin_info_t>::iterator iter;

    //writer.unsetf(std::ios::out | std::ios_base::binary);
    //writer.setf(std::ios::app | std::ios_base::binary);

    if (AllocateEncodeBuffer(&buffer, &out_buffer) != S_DONE) {
        return FAIL;
    }

    for (iter = (*bins).begin(); iter != (*bins).end(); ++iter) {
        bin_info_t bin_info = *iter;
        string s = bin_info.filePath;
        fstream reader(s.c_str(), std::ios::in | std::ios_base::binary);

        if (!reader) {
            cout << endl << "cannot open input file: " << s << endl;
            cout << "The file might be opened or it might be not exist."
                 << endl;

            FreeEncodeBuffer(&buffer, &out_buffer);
            return E_File_OPEN_FAIL;
        }

        SHA1Init(&ctx);

        U32 bin_pack_size = 0;
        U32 bin_unpack_size = 0;
        CLzmaEncHandle enc;
        CLzmaEncProps props;
        SRes res;
        Byte lzmaHeader[LZMA_PROPS_SIZE + 8];
        size_t headerSize = LZMA_PROPS_SIZE;

        if (bin_info.isCompressed == 1) {
            // lzma init
            enc = LzmaEnc_Create(&g_Alloc);
            if (enc == 0) {
                FreeEncodeBuffer(&buffer, &out_buffer);
                return SZ_ERROR_MEM;
            }
            LzmaEncProps_Init(&props);

            props.level = 0;
            props.dictSize = 1 << 14;   // DO NOT CHANGE. This affects decode buffer size (set to 16KB).

            res = LzmaEnc_SetProps(enc, &props);

            // construct lzma header
            UInt64 fileSize;
            res = LzmaEnc_WriteProperties(enc, lzmaHeader, &headerSize);
            fileSize = MyGetFileSize(s);

            int i;
            for (i = 0; i < 8; i++)
                lzmaHeader[headerSize++] = (Byte)(fileSize >> (8 * i));

            writer.write((char *)lzmaHeader, headerSize);
            bin_pack_size += headerSize;
            SHA1Update(&ctx, (unsigned char *)lzmaHeader, headerSize);
        }

        /* =====================================================================
         */
        // reader.read(GFH_check_buffer, sizeof(GFH_check_buffer));
        // bin_size = reader.gcount();

        // writer.write(GFH_check_buffer, reader.gcount());

        while (!reader.eof()) {
            reader.read(buffer, MAX_BUFFER_SIZE);
            SizeT inSize = reader.gcount();
            // bin_size += inSize;
            if (bin_info.isCompressed == 1) {
                SizeT outSize = MAX_OUT_BUFFER_SIZE;
                size_t outPropsSize = 5;
                res = LzmaEncode((Byte *)out_buffer, &outSize, (Byte *)buffer,
                                 inSize, &props, lzmaHeader, &headerSize, 0,
                                 NULL, &g_Alloc, &g_Alloc);
                writer.write(out_buffer, outSize);
                cout << "lzma output size=" << outSize << endl;
                bin_pack_size += outSize;
                bin_unpack_size = inSize;
                SHA1Update(&ctx, (unsigned char *)out_buffer, outSize);
            } else {
                writer.write(buffer, inSize);
                bin_unpack_size += inSize;
                bin_pack_size = bin_unpack_size;
                SHA1Update(&ctx, (unsigned char *)buffer, inSize);
            }

            // writer.write(buffer, reader.gcount());
        }

        if (bin_info.isCompressed == 1) {
            LzmaEnc_Destroy(enc, &g_Alloc, &g_Alloc);
        }

        SHA1Final(hash, &ctx);
        // fill SHA1 hash code
        writer.write((char *)hash, SHA1_HASH_CODE_LEN);

        // fill Header Info
        int ret;
        if ((ret = FillHeaderInfo(bin_count, offset, bin_pack_size,
                                  bin_unpack_size, *iter)) != S_DONE) {
            cout << "fill header fail" << endl;

            if (ret == E_PARTITION_NOT_ENOUGH) {
                cout << "Partition size is not enough for upgrade bin size."
                     << endl;
            }

            FreeEncodeBuffer(&buffer, &out_buffer);
            return ret;
        }

        bin_count += 1;
        offset += bin_pack_size + SHA1_HASH_CODE_LEN;
        reader.close();
    }

    // fill magic number and bin number.
    header.m_magic_ver = 0x004D4D4D;
    header.m_bin_num = bin_count;

    // calculate header info hash
    SHA1Init(&ctx);
    SHA1Update(&ctx, (const unsigned char *)&header, sizeof(IOT_FOTA_HEADER));
    SHA1Final(hash, &ctx);

    // insert IOT FOTA HEADER to the beginning of the output bin
    writer.seekp(0);
    memcpy(buffer, &header, sizeof(IOT_FOTA_HEADER));
    writer.write(buffer, sizeof(IOT_FOTA_HEADER));

    // insert header info hash value
    writer.write((const char *)hash, SHA1_HASH_CODE_LEN);
    writer.close();

    FreeEncodeBuffer(&buffer, &out_buffer);

    return S_DONE;
}

int BinBuilder::FillHeaderInfo(U32 bin_count, U32 offset, U32 bin_pack_size,
                               U32 bin_unpack_size, bin_info_t &bin_info) {
    // check partition size is enough or not.
    if (bin_info.partition_size < bin_unpack_size) {
        return E_PARTITION_NOT_ENOUGH;
    }

    header.m_extra_info[bin_count].m_bin_offset = offset;
    header.m_extra_info[bin_count].m_bin_start_addr = bin_info.start_addr;
    header.m_extra_info[bin_count].m_partition_length = bin_info.partition_size;
    header.m_extra_info[bin_count].m_bin_length = bin_pack_size;
    header.m_extra_info[bin_count].m_sig_lenth = SHA1_HASH_CODE_LEN;
    header.m_extra_info[bin_count].m_sig_offset = offset + bin_pack_size;
    header.m_extra_info[bin_count].m_is_compressed = bin_info.isCompressed;

    return S_DONE;
}

int BinBuilder::AllocateEncodeBuffer(char **inBuf, char **outBuf) {
    // malloc lzma working buffer
    char *ptr = NULL;
    ptr = (char *)malloc(MAX_BUFFER_SIZE);
    if (ptr == NULL) {
        cout << endl << "cannot malloc lzma working buffer" << endl;
        return FAIL;
    } else {
        *inBuf = ptr;
    }

    ptr = (char *)malloc(MAX_OUT_BUFFER_SIZE);
    if (ptr == NULL) {
        cout << endl << "cannot malloc lzma working buffer" << endl;
        return FAIL;
    } else {
        *outBuf = ptr;
    }
    return S_DONE;
}

int BinBuilder::FreeEncodeBuffer(char **inBuf, char **outBuf) {
    // free lzma working buffer
    free(*inBuf);
    free(*outBuf);
    return S_DONE;
}

// Read bin info from json file. Assume max json file size < 1MB.
bool GetBinInfoFromJson(const string &jsonPath, wstring &outputPath,
                        vector<bin_info_t> &result) {
    const size_t MAX_JSON_SIZE = 1 * 1024 * 1024;
    FILE *fp = fopen(jsonPath.c_str(), "rb");

    if (NULL == fp) {
        cout << "file not found:" << jsonPath << endl;
        return false;
    }

    vector<char> jsonContent;
    jsonContent.resize(MAX_JSON_SIZE);
    const size_t jsonFileSize =
        fread(&jsonContent[0], 1, jsonContent.size(), fp);
    cout << "json file size=" << jsonFileSize << endl;
    cJSON *root = cJSON_Parse(&jsonContent[0]);

    do {
        if (!root) {
            cout << "invalid json format" << endl;
        }

        // "output" is a string of output FOTA bin path
        cJSON *output_path = cJSON_GetObjectItem(root, "output");
        if (!output_path || output_path->type != cJSON_String) {
            cout << "no output_path defined" << endl;
            break;
        }
        string outputPathA = output_path->valuestring;
        outputPath = wstring(outputPathA.begin(), outputPathA.end());

        // "bins" should be an array of dictionaries
        cJSON *bins = cJSON_GetObjectItem(root, "bins");
        if (!bins) {
            cout << "no bins defined" << endl;
            break;
        }
        if (!bins || bins->type != cJSON_Array) {
            cout << "invalid bins" << endl;
            break;
        }

        // iterate through each iteam
        for (int i = 0; i < cJSON_GetArraySize(bins); i++) {
            cout << "bin_info #" << i << endl;
            bin_info_t info;
            // each subitem should be a dict full of bin info
            cJSON *subitem = cJSON_GetArrayItem(bins, i);

            if (subitem) {
                cJSON *file_path = cJSON_GetObjectItem(subitem, "file_path");
                if (file_path && file_path->type == cJSON_String) {
                    info.filePath = file_path->valuestring;
                }
                cJSON *start_addr = cJSON_GetObjectItem(subitem, "start_addr");
                if (start_addr && start_addr->type == cJSON_String) {
                    info.start_addr = strtoul(start_addr->valuestring, NULL, 0);
                }
                cJSON *partition_size =
                    cJSON_GetObjectItem(subitem, "partition_size");
                if (partition_size && partition_size->type == cJSON_String) {
                    info.partition_size =
                        strtoul(partition_size->valuestring, NULL, 0);
                }
                cJSON *is_compressed =
                    cJSON_GetObjectItem(subitem, "is_compressed");
                if (is_compressed) {
                    info.isCompressed = (cJSON_True == is_compressed->type);
                }
                result.push_back(info);

                cout << info;
            }
        }
    } while (false);

    cJSON_Delete(root);
    fclose(fp);

    return true;
}

ostream &operator<<(ostream &os, const bin_info_t &info) {
    os << "file path:" << info.filePath << endl;
    os << "start addr:0x" << hex << info.start_addr << endl;
    os << "partition size:0x" << hex << info.partition_size << endl;
    os << "isCompressed:" << info.isCompressed << endl;
    return os;
}

void print_usage() {
    cout << "Usage: " PROJ_NAME " [path_to_config_file]" << endl;
    cout << "\nBy default the program loads \"config.json\" in the "
            "same\ndirectory. Alternatively you can pass config file path\nto "
            "assign path to the JSON config file.\n";
    cout << "\nThe JSON config file should contain these "
            "attributes.\n\t'output': assign output path.\n\t'bins': an array "
            "of "
            "dictionay. Each item represents a "
            "bin:\n\t\t'file_path'(string)\n\t\t'start_addr'(string)\n\t\t'"
            "partition_size'(string)\n\t\t'is_compressed'(bool)\nNote that "
            "'start_addr' and 'partition_size' are strings instead of numbers "
            "to\naccept C-style hex literal such as '0xFFEF'\n";
}

int main(int argc, char **argv) {
    // collect bin info and output path
    std::wstring outputPath;
    vector<bin_info_t> inputBinList;

    if (argc == 2) {
        string configFile = argv[1];
        // config json given
        GetBinInfoFromJson(configFile.c_str(), outputPath, inputBinList);
    } else if (argc == 1) {
        // default load from "config.json"
        GetBinInfoFromJson("config.json", outputPath, inputBinList);
    }

    if (inputBinList.size() < 1) {
        print_usage();
        return 0;
    }

    // Generate FOTA bin
    BinBuilder builder;
    builder.GenerateNewBin(&inputBinList, outputPath);

    return 0;
}
