#ifndef __BINBUILDER_ERROR_H__
#define __BINBUILDER_ERROR_H__

#define S_DONE                              0 
#define FAIL                                1
#define E_Base_Directory_NOT_EXIST_IN_INI   2
#define E_BinFile_NOT_EXIST_IN_INI          3
#define E_File_OPEN_FAIL                    4
#define E_PARTITION_NOT_ENOUGH              5


#endif