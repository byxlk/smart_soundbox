#!/bin/sh

mkdir build
cd build
cmake ..
cmake --build .
cp ./BinBuilder ../
cd ..