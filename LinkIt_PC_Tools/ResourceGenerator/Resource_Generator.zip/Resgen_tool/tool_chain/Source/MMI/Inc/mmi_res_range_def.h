/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */#ifndef MMI_RES_REANGE_DEF_H
#define MMI_RES_REANGE_DEF_H

#include "MMI_features.h"

/****************************************************************************
*
* Resource Base ID
*
* Note: We define the the starting value of resource enum ID 
*       for each application instead of using one big enum definition.
*       As a result, we can avoid re-compile of the whole plutommi 
*       when add/remove string/image enum ID.
* 
* Note: The maximum value of resource ID is 65535 due to U16 datatype.
*
*****************************************************************************/

#undef EMPTY_RANGE
#define EMPTY_RANGE  (2)

/*
 * Use these tow macro to get the resource base and resource end
 */
#define GET_RESOURCE_BASE(id)   RESOURCE_BASE_##id
#define GET_RESOURCE_MAX(id)    RESOURCE_BASE_##id##_END

/*
 * Use this macro two to declare resource id range between RESOURCE_BASE_ENUM_BEGIN()
 * and RESOURCE_BASE_ENUM_END()
 */
#define RESOURCE_BASE_RANGE(ap_id, count)    \
    ap_id,                                   \
    GET_RESOURCE_BASE(ap_id) = ap_id,        \
    GET_RESOURCE_MAX(ap_id) = ap_id + count
    
/*
 * Because wap.lib will use resource, RESOURCE_BASE_APP_WAP need to be front of the table
 * to make sure resource id is fixed 
 */
#define RESOURCE_BASE_ENUM_BEGIN()      \
    typedef enum                                    \
    {/* reserve 0 to be string or img */            \
        //RESOURCE_BASE_FIRST_VALUE = 3000,           \
        //RESOURCE_BASE_RANGE(APP_GLOBALDEFS,  299),

/*
 * Because RESOURCE_BASE_APP_DEVAPP is defined for vendor developing and it has 
 * another resource table, "Resource" will search the different tables 
 * according to the resource base.
 * 
 * In general, the new resource base should be added before APP_DEVAPP.
 */
#define RESOURCE_BASE_ENUM_END()                    \
        RESOURCE_BASE_RANGE(APP_DEVAPP,    900),    \
        RESOURCE_BASE_RANGE(APP_DEFAULT_END, 1),    \
        RESOURCE_BASE_RANGE(END, 1)                 \
    } RESOURCE_BASE_ENUM;


#define MMI_RES_DECLARE(_name, _range, _res_path)   \
            RESOURCE_BASE_RANGE(_name, _range),

/* 
 * Declare the range of resource ID of each application.
 *      RESOURCE_BASE_RANGE(<app id>, <resource range>),
 * Or Sevice without the concept of applicatioin
 *      RESOURCE_BASE_RANGE(<sevice id>, <resource range>)
 *
 * For example:
 *      For applications:
 *          RESOURCE_BASE_RANGE(APP_XXX1,   100),
 *          RESOURCE_BASE_RANGE(APP_XXX2,    50),
 *      For Services:
 *          RESOURCE_BASE_RANGE(SRV_XXX1,   200),
 *          RESOURCE_BASE_RANGE(SRV_XXX2,   100),
 */

RESOURCE_BASE_ENUM_BEGIN()
    /**************************************************************************************
     * Declare resource ID range below 
     **************************************************************************************/
    RESOURCE_BASE_RANGE(DEFAULT_RESOURCE,                  2),
    RESOURCE_BASE_RANGE(CUSTOM,                  1000),

    /**************************************************************************************
     * Declare resource ID range above 
     **************************************************************************************/
RESOURCE_BASE_ENUM_END()

/*
 * Fill resouce table and define resouce base and max macro for each application
 * or service.
 *
 */

/*
 * Structure for resouce table element
 */
typedef struct 
{
    char *appname;        /* Application or service name. eg. APP_XXX or SRV_XXX */
    unsigned short min;   /* Resouce ID start position of an application or service */
    unsigned short max;   /* Resouce ID end position of an application or service */
    char res_path[512];
} mmi_resource_base_struct;


#if (defined(_POPULATE_RES_C) && !defined(PRODUCTION_RELEASE)) || defined(RESGEN_XML_C)

/* Table of resource base ID used for reference in debugging */
#define RESOURCE_BASE_TABLE_BEGIN()         \
    const   mmi_resource_base_struct g_mmi_resource_base_table[] = {

/* Use the Macro to insert an element to resouce table */
#define RESOURCE_BASE_TABLE_ITEM(ENUM_NAME) \
        {#ENUM_NAME, (U16) GET_RESOURCE_BASE(ENUM_NAME), (U16) GET_RESOURCE_MAX(ENUM_NAME), ""},
        
        
#define RESOURCE_BASE_TABLE_ITEM_PATH(ENUM_NAME, RES_PATH) \
        {#ENUM_NAME, (U16) GET_RESOURCE_BASE(ENUM_NAME), (U16) GET_RESOURCE_MAX(ENUM_NAME), RES_PATH},
        

#define RESOURCE_BASE_TABLE_END()                                          \
        {"END", (U16) GET_RESOURCE_BASE(END), (U16) GET_RESOURCE_MAX(END), ""} \
    };

#else /* _POPULATE_RES_C */

#define RESOURCE_BASE_TABLE_BEGIN()

#define RESOURCE_BASE_TABLE_ITEM(ENUM_NAME)
#define RESOURCE_BASE_TABLE_ITEM_PATH(ENUM_NAME, RES_PATH)

#define RESOURCE_BASE_TABLE_END()

#endif /* _POPULATE_RES_C */


#undef MMI_RES_DECLARE
#define MMI_RES_DECLARE(_name, _range, _res_path)   \
            RESOURCE_BASE_TABLE_ITEM_PATH(_name, _res_path)

/* 
 * Fill resouce table and define XXX_BASE and XXX_BASE_XXX for each application
 * or service.
 * 
 * For application:
 *   #define XXX_BASE     ((U16) GET_RESOURCE_BASE(APP_XXX))
 *   #define XXX_BASE_MAX ((U16) GET_RESOURCE_MAX(APP_XXX))
 *   RESOURCE_BASE_TABLE_ITEM(APP_XXX)
 * For service:
 *   #define XXX_BASE     ((U16) GET_RESOURCE_BASE(SRV_XXX))
 *   #define XXX_BASE     ((U16) GET_RESOURCE_MAX(SRV_XXX))
 *   RESOURCE_BASE_TABLE_ITEM(SRV_XXX)
 */


/* Beginning of resource table */
RESOURCE_BASE_TABLE_BEGIN()
/****************************************************************************
* Default
*****************************************************************************/
#define DEFAULT_BASE                      ((U16) GET_RESOURCE_BASE(DEFAULT_RESOURCE))
#define DEFAULT_BASE_MAX                  ((U16) GET_RESOURCE_MAX(DEFAULT_RESOURCE))
RESOURCE_BASE_TABLE_ITEM_PATH(DEFAULT_RESOURCE, "..\\default_resource\\")

/****************************************************************************
* Custom
*****************************************************************************/
#define CUSTOM_BASE                      ((U16) GET_RESOURCE_BASE(CUSTOM))
#define CUSTOM_BASE_MAX                  ((U16) GET_RESOURCE_MAX(CUSTOM))
RESOURCE_BASE_TABLE_ITEM_PATH(CUSTOM, "..\\..\\custom_resource\\")

/*****************************************************************************/
/* please add new resource base table above this line */
/* End of resource table */
RESOURCE_BASE_TABLE_END()

#endif /* MMI_RES_REANGE_DEF_H */

