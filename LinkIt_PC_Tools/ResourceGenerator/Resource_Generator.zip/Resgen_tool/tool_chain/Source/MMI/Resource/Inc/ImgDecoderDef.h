/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#ifndef __IMG_DECODER_DEF_H__
#define __IMG_DECODER_DEF_H__

#include "ResBytestream.h"

#define WINGUI_DIRECT_IMAGE_DISPLAY          0
#define WINGUI_HW_COLOR_DEPTH_12          1
#define DEVICE_COLOR_DEPTH                12
#define  IMAGE_STATIC_ROW_DATA_SIZE          1024
#define IMAGE_STATIC_PALETTE_SIZE            768
#define IMAGE_STATIC_BUFFER_SIZE          409600
#define UI_UNUSED_PARAMETER(x)               (void)(x)

/* MACROS defined by Pluto */

/* 070306 Alpha layer Start */
#if (defined(MTKLCM_COLOR) || defined(INFOLCM) || defined(POWERTIP_LCM) || defined(SCORPIOB1_LCM))
#define  MMI_RGB_TO_HW_FORMAT(R,G,B)   ( (((B)&0xf8)<<5)|(((R)&0xf8))|(((G)&0xe0)>>5)|(((G)&0x1c)<<11) )
#else 
#define  MMI_RGB_TO_HW_FORMAT(R,G,B)   ( (((B)&0xf8)>>3)|(((G)&0xfc)<<3)|(((R)&0xf8)<<8) )
#endif 
#define  MMI_RGB_TO_HW_FORMAT_1(A,R,G,B)  ( ((U16)(((S32)(R)+(S32)(G)+(S32)(B))/(S32)3)>=0x80)? 1:0 )
#define  MMI_RGB_TO_HW_FORMAT_16(A,R,G,B) MMI_RGB_TO_HW_FORMAT(R,G,B)
#define  MMI_RGB_TO_HW_FORMAT_24(A,R,G,B) ((R << 16) | (G << 8) | B)
#define  MMI_RGB_TO_HW_FORMAT_32(A,R,G,B) ((A << 24) | (R << 16) | (G << 8) | B)

/* Macros to handle color omission transparency */
#define RGB_TRANSPARENT_COLOR_16          (0x1234)
#define TEST_RGB_TRANSPARENT_COLOR_16(value) ((value)==RGB_TRANSPARENT_COLOR_16)
#define SET_RGB_TRANSPARENT_COLOR_16(value)     ((value)=RGB_TRANSPARENT_COLOR_16)
#define RGB_TRANSPARENT_COLOR_24                (0x123456)
#define TEST_RGB_TRANSPARENT_COLOR_24(value)    ((value)==RGB_TRANSPARENT_COLOR_24)
#define SET_RGB_TRANSPARENT_COLOR_24(value)     ((value)=RGB_TRANSPARENT_COLOR_24)
#define RGB_TRANSPARENT_COLOR_32                (0x12345678)
#define TEST_RGB_TRANSPARENT_COLOR_32(value)    ((value)==RGB_TRANSPARENT_COLOR_32)
#define SET_RGB_TRANSPARENT_COLOR_32(value)     ((value)=RGB_TRANSPARENT_COLOR_32)
/* 070306 Alpha layer Start */

typedef struct _bitmap
{
    S32 xsize;
    S32 ysize;
    S8 color_depth;
    S32 row_bytes;
    U8 *palette;
    U8 *data;
} bitmap;

/* Support for BMP files      */

typedef struct _bitmap_file_header
{
    U16 file_type;
    U32 file_size;
    U16 reserved1;
    U16 reserved2;
    U32 bitmap_offset;
} bitmap_file_header;

typedef struct _bitmap_info_header
{
    U32 header_size;
    U32 width;
    U32 height;
    U16 number_of_planes;
    U16 bits_per_pixel;
    U32 compression;
    U32 bitmap_size;
    U32 device_width;
    U32 device_height;
    U32 number_of_colors;
    U32 number_of_important_colors;
} bitmap_info_header;

extern void BMP_load_file_header(bitmap_file_header *h, bytestream *file);
extern void BMP_load_info_header(bitmap_info_header *h, bytestream *file);
#endif /* __IMG_DECODER_DEF_H__ */ 

