/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#include <stdio.h>
#include <stdlib.h>

#include "ResDevice.h"
#include "ResBytestream.h"
#include "ImgDecoderDef.h"
#include "mmi_features.h"

#include "WriteResUtil.h"

extern FILE *dest_file;
extern int toolFlag;

U8 binary_mode = 0;
U8 verbose_mode = 0;

#ifdef __MMI_RESOURCE_ENFB_SUPPORT__
extern FILE *enfb_img_data_file;
extern U32 enfb_offset;
extern U32 enfb_size;
extern MMI_BOOL ENFBAssociatedIDAdded;

#include "ImageGetDimension.h"
#endif


/*****************************************************************************
 * FUNCTION
 *  EMS_load
 * DESCRIPTION
 *  
 * PARAMETERS
 *  file            [?]     
 *  filename        [?]     
 * RETURNS
 *  
 *****************************************************************************/
static U8 EMS_load(bytestream *file, char *filename, ResgenImageOutStream * outstream, SetImageProcessData * processData)
{
    /*----------------------------------------------------------------*/
    /* Local Variables                                                */
    /*----------------------------------------------------------------*/
    bitmap_file_header file_header;
    bitmap_info_header info_header;
    S32 i, j, k;
    S32 bits_per_pixel, width, height, PDU_length;
    U8 buffer[2048];
    U8 mask;
    U8 data;
    char cmdbuf[1024];
    FILE *file_ptr;
    S32 file_length;
    U8 *file_buffer;
    bytestream *rgb_image;
    U8 scale_data;
#ifdef __MMI_RESOURCE_ENFB_SUPPORT__
    U32 enfb_width, enfb_height;
    S32 enfb_ret;
#endif
    char temp_filename1[1024];
    char temp_filename2[1024];

    /*----------------------------------------------------------------*/
    /* Code Body                                                      */
    /*----------------------------------------------------------------*/
    BMP_load_file_header(&file_header, file);
    if ((file_header.file_type & 0xff) != 'B')
    {
        printf("\nNot a valid BMP file");
        return (0);
    }
    if ((file_header.file_type >> 8) != 'M')
    {
        printf("\nNot a valid BMP file");
        return (0);
    }
    BMP_load_info_header(&info_header, file);
    width = info_header.width;
    height = info_header.height;
    if (info_header.bits_per_pixel == 1)
    {
        bits_per_pixel = 1;
        PDU_length = ((width * height) + 7) >> 3;

    }
    else if (info_header.bits_per_pixel == 4)
    {
        bits_per_pixel = 2;
        PDU_length = (((width * height) << 1) + 7) >> 3;
    }
    else if (info_header.bits_per_pixel == 8)
    {
        bits_per_pixel = 6;
        PDU_length = (((width * height) * 6) + 7) >> 3;
    }
    else
    {
        return (0);
    }

    processData->res_size = PDU_length;

    bytestream_fseek(file, file_header.bitmap_offset, SEEK_SET);
    Extract_Name(temp_filename1, filename, SYSTEM_IMAGE);
    strcpy(temp_filename2, ".\\temp\\");
    strcat(temp_filename2, temp_filename1);
    strcat(temp_filename2, "_temp.rgb");
    sprintf(cmdbuf, "%s %s %s", "..\\..\\Customer\\ResGenerator\\convert.exe", filename, temp_filename2);
    system(cmdbuf);
    file_ptr = fopen(temp_filename2, "rb");
    if (file_ptr == NULL)
    {
        printf("\nfile_ptr open failed\n");
        return (0);            
    }
    fseek(file_ptr, 0, SEEK_END);
    file_length = ftell(file_ptr);
    fseek(file_ptr, 0, SEEK_SET);
    file_buffer = (U8*) malloc(file_length);
    if (file_buffer == NULL)
    {
        printf("\file_buffer malloc failed\n");
        fclose(file_ptr);
        return (0);            
    }
    fread(file_buffer, 1, file_length, file_ptr);
    fclose(file_ptr);
    bytestream_initialize(&rgb_image, file_buffer, file_length);
    free(file_buffer);

    if (binary_mode)
    {
        if (bits_per_pixel == 1)
        {
            for (i = 0; i < PDU_length; i++)
            {
                buffer[i] = 0x00;
                for (k = 8; k; k--)
                {
                    data =
                        (bytestream_fgetbyte(&rgb_image) + bytestream_fgetbyte(&rgb_image) +
                         bytestream_fgetbyte(&rgb_image)) / 3;
                    if (data >= 0 && data < 128)
                    {
                        scale_data = 0x01;
                    }
                    else
                    {
                        scale_data = 0x00;
                    }
                    buffer[i] |= scale_data << (k - 1);
                }
            }
        }
        else if (bits_per_pixel == 2)
        {
            for (i = 0; i < PDU_length; i++)
            {
                buffer[i] = 0x00;
                for (k = 8; k; k = k - 2)
                {
                    data =
                        (bytestream_fgetbyte(&rgb_image) + bytestream_fgetbyte(&rgb_image) +
                         bytestream_fgetbyte(&rgb_image)) / 3;
                    if (data >= 0 && data < 64)
                    {
                        scale_data = 0x00;
                    }
                    else if (data >= 64 && data < 128)
                    {
                        scale_data = 0x01;
                    }
                    else if (data >= 128 && data < 192)
                    {
                        scale_data = 0x02;
                    }
                    else
                    {
                        scale_data = 0x03;
                    }
                    buffer[i] |= scale_data << (k - 2);
                }
            }
        }
        else if (bits_per_pixel == 6)
        {
            for (i = 0; i < PDU_length; i++)
            {
                buffer[i] = 0x00;
                for (k = 8; k; k = k - 2)
                {
                    data = bytestream_fgetbyte(&rgb_image);
                    if (data >= 0 && data < 64)
                    {
                        scale_data = 0x00;
                    }
                    else if (data >= 64 && data < 128)
                    {
                        scale_data = 0x01;
                    }
                    else if (data >= 128 && data < 192)
                    {
                        scale_data = 0x02;
                    }
                    else
                    {
                        scale_data = 0x03;
                    }
                    buffer[i] |= scale_data << (k - 2);
                }
            }
        }
    #ifdef __MMI_RESOURCE_ENFB_SUPPORT__
        enfb_ret = Image_Test(filename, &enfb_width, &enfb_height, processData->disable_enfb);
        if (enfb_ret != ENFB_IMAGE_NONE)
        {
            processData->enfb_flag = 1;
            if (enfb_ret == ENFB_IMAGE_ASSOCIATE)
            {
                ENFBAssociatedIDAdded = MMI_TRUE;
            }
        }
    #endif
        if (toolFlag == 1)  /* Write to file in binary format */
        {
            fprintf(
                dest_file,
                "%c%c%c%c%c%c%c%c%c",
                (U8) 1,
                (U8) bits_per_pixel,
                (U8) 0,
                (U8) (width & 0xff),
                (U8) ((width >> 8) & 0xff),
                (U8) (height & 0xff),
                (U8) ((height >> 8) & 0xff),
                (U8) ((PDU_length) & 0xff),
                (U8) ((PDU_length) >> 8) & 0xff);
            for (i = 0; i < PDU_length; i++)
            {
                fprintf(dest_file, "%c", buffer[i]);
            }
        }
    #ifdef __MMI_RESOURCE_ENFB_SUPPORT__
        else if (processData->enfb_flag == 1) /* write ENFB header to CustImgDataxxx.h and image header/data to ENFB image data file */
        {
            enfb_size = 9 + PDU_length;
            
            /* write ENFB header to CustImgDataxxx.h */
            ImageOutStreamPrintf(outstream,
                "\n{\t0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X\t};\n",
                (U8) 255,//type
                (U8) ENFBAssociatedIDAdded,//associated id
                (U8) 0,//reserved
                (U8) 0,//reserved
                (U8) (enfb_offset & 0xff),
                (U8) ((enfb_offset >> 8) & 0xff),
                (U8) ((enfb_offset >> 16) & 0xff),
                (U8) ((enfb_offset >> 24) & 0xff),
                (U8) (enfb_size & 0xff),
                (U8) ((enfb_size >> 8) & 0xff),
                (U8) ((enfb_size >> 16) & 0xff),
                (U8) ((enfb_size >> 24) & 0xff));
            
            /* image header/data to ENFB image data file */
            fprintf(
                enfb_img_data_file,
                "%c%c%c%c%c%c%c%c%c",
                (U8) 1,
                (U8) bits_per_pixel,
                (U8) 0,
                (U8) (width & 0xff),
                (U8) ((width >> 8) & 0xff),
                (U8) (height & 0xff),
                (U8) ((height >> 8) & 0xff),
                (U8) ((PDU_length) & 0xff),
                (U8) ((PDU_length) >> 8) & 0xff);
            for (i = 0; i < PDU_length; i++)
            {
                fprintf(enfb_img_data_file, "%c", buffer[i]);
            }
            
            enfb_offset += enfb_size;
            processData->enfb_flag = 0;
        }
    #endif
        else    /* Write to .c .h file */
        {
            ImageOutStreamPrintf(outstream,
                "\n{\t0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X,",
                (U8) 1,
                (U8) bits_per_pixel,
                (U8) 0,
                (U8) (width & 0xff),
                (U8) ((width >> 8) & 0xff),
                (U8) (height & 0xff),
                (U8) ((height >> 8) & 0xff),
                (U8) ((PDU_length) & 0xff),
                (U8) ((PDU_length) >> 8) & 0xff);
            for (i = 0; i < PDU_length; i++)
            {
                if ((i % 16) == 0)
                {
                    ImageOutStreamPrintf(outstream, "\n\t");
                }
                ImageOutStreamPrintf(outstream, "0x%02X, ", buffer[i]);
            }
            ImageOutStreamPrintf(outstream, "\n};\n");
        }
    }
    else
    {
        if (verbose_mode)
        {
            printf("\nWidth=%d, Height=%d, Size=%d bytes", width, height, PDU_length);
        }
        if (bits_per_pixel == 1)
        {
            for (i = 0; i < PDU_length; i++)
            {
                buffer[i] = 0x00;
                for (k = 8; k; k--)
                {
                    data =
                        (bytestream_fgetbyte(&rgb_image) + bytestream_fgetbyte(&rgb_image) +
                         bytestream_fgetbyte(&rgb_image)) / 3;
                    if (data >= 0 && data < 128)
                    {
                        scale_data = 0x01;
                    }
                    else
                    {
                        scale_data = 0x00;
                    }
                    buffer[i] |= scale_data << (k - 1);
                }
            }
        }
        else if (bits_per_pixel == 2)
        {
            for (i = 0; i < PDU_length; i++)
            {
                buffer[i] = 0x00;
                for (k = 8; k; k = k - 2)
                {
                    data =
                        (bytestream_fgetbyte(&rgb_image) + bytestream_fgetbyte(&rgb_image) +
                         bytestream_fgetbyte(&rgb_image)) / 3;
                    if (data >= 0 && data < 64)
                    {
                        scale_data = 0x00;
                    }
                    else if (data >= 64 && data < 128)
                    {
                        scale_data = 0x01;
                    }
                    else if (data >= 128 && data < 192)
                    {
                        scale_data = 0x02;
                    }
                    else
                    {
                        scale_data = 0x03;
                    }
                    buffer[i] |= scale_data << (k - 2);
                }
            }
        }
        else if (bits_per_pixel == 6)
        {
            for (i = 0; i < PDU_length; i++)
            {
                buffer[i] = 0x00;
                for (k = 8; k; k = k - 2)
                {
                    data = bytestream_fgetbyte(&rgb_image);
                    if (data >= 0 && data < 64)
                    {
                        scale_data = 0x00;
                    }
                    else if (data >= 64 && data < 128)
                    {
                        scale_data = 0x01;
                    }
                    else if (data >= 128 && data < 192)
                    {
                        scale_data = 0x02;
                    }
                    else
                    {
                        scale_data = 0x03;
                    }
                    buffer[i] |= scale_data << (k - 2);
                }
            }
        }
        if (verbose_mode)
        {
            printf("\nImage Data:");
        }
        printf(
            "\n{\t0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X,",
            (U8) 1,
            (U8) bits_per_pixel,
            (U8) 0,
            (U8) (width & 0xff),
            (U8) ((width >> 8) & 0xff),
            (U8) (height & 0xff),
            (U8) ((height >> 8) & 0xff),
            (U8) ((PDU_length) & 0xff),
            (U8) ((PDU_length) >> 8) & 0xff);
    }
    if (verbose_mode)
    {
        printf("\nConvert OK\n");
    }
    return (1);
}


/*****************************************************************************
 * FUNCTION
 *  bmp2ems
 * DESCRIPTION
 *  
 * PARAMETERS
 *  in_filename         [?]         
 *  out_filename        [?]         
 *  binary_flag         [IN]        
 *  verbose_flag        [IN]        
 * RETURNS
 *  
 *****************************************************************************/
int bmp2ems(char *in_filename, ResgenImageOutStream * outstream, int binary_flag, int verbose_flag, SetImageProcessData * processData)
{
    /*----------------------------------------------------------------*/
    /* Local Variables                                                */
    /*----------------------------------------------------------------*/
    FILE *infile;
    bytestream inimage;
    S32 file_length;
    U8 *buffer;
    S32 i, bitmap_size, total_data_size;
    int ret;

    /*----------------------------------------------------------------*/
    /* Code Body                                                      */
    /*----------------------------------------------------------------*/
    infile = fopen(in_filename, "rb");
    if (infile == NULL)
    {
        printf("\nErr opening %s", in_filename);
        return 0;
    }

    if (binary_flag == 1)
    {
        binary_mode = 1;
    }

    if (verbose_flag == 1)
    {
        verbose_mode = 1;
    }

    if (verbose_mode)
    {
        printf("\nBMP to EMS PDU converter");
        printf("\n(c) 2003 Pixtel communications Inc.");
    }

    fseek(infile, 0, SEEK_END);
    file_length = ftell(infile);
    fseek(infile, 0, SEEK_SET);

    buffer = (U8*) malloc(file_length);
    if (buffer == NULL)
    {
        printf("\nErr allocating memory of size %d bytes", file_length);
        fclose(infile);
        return 0;
    }

    fread(buffer, 1, file_length, infile);
    fclose(infile);
    bytestream_initialize(&inimage, buffer, file_length);
    ret = EMS_load(&inimage, in_filename, outstream, processData);
    free(buffer);
    return ret;
}
