/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
/**
 * Copyright Notice
 * (c) 2002 - 2003, Pixtel Communications, Inc., 1489 43rd Ave. W.,
 * Vancouver, B.C. V6M 4K8 Canada. All Rights Reserved.
 *  (It is illegal to remove this copyright notice from this software or any
 *  portion of it)
 */

/**********************************************************************************
   External tool required for the MMI

   Filename:      bytestream.h
   Author:        manju
   Date Created:  June-10-2002
   Contains:      bytestream data type header file
               These are used to process ROM images of binary files
**********************************************************************************/

#ifndef __BYTESTREAM_H__
#define __BYTESTREAM_H__

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */ 

#include <stdio.h>
#include <stdlib.h>
#include "ResDevice.h"

    typedef struct _bytestream
    {
        long int size;
        long int current_offset;
        U8 *data;
    } bytestream;

    extern void bytestream_initialize(bytestream *file, U8 *data, long int size);
    extern void bytestream_fclose(bytestream *file);
    extern U8 bytestream_fseek(bytestream *file, long int offset, int mode);
    extern U8 bytestream_feof(bytestream *file);
    extern U8 bytestream_fgetbyte(bytestream *file);
    extern U8 bytestream_fputbyte(bytestream *file, U8 c);
    extern size_t bytestream_fread(U8 *buffer, size_t size, size_t number, bytestream *file);
    extern U16 bytestream_fgetword(bytestream *file);
    extern U32 bytestream_fgetdword(bytestream *file);
    extern U8 bytestream_fputword(bytestream *file, U16 w);
    extern U8 bytestream_fputword_bigendian(bytestream *file, U16 w);
    extern U8 bytestream_fputdword(bytestream *file, U32 d);
    extern U8 bytestream_fputdword_bigendian(bytestream *file, U32 d);
    extern U16 bytestream_fgetword_bigendian(bytestream *file);
    extern U32 bytestream_fgetdword_bigendian(bytestream *file);
    /* Used to read variable length data: Useful only for MIDI files  */
    extern U32 bytestream_fgetvdata(bytestream *file);

#ifdef __cplusplus
}
#endif 

#endif /* __BYTESTREAM_H__ */ 

