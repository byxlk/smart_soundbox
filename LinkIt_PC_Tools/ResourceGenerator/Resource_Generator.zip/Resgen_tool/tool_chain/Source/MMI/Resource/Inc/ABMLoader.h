/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#ifndef __ABMLOADER_H__
#define __ABMLOADER_H__

/***************************************************************************** 
 * Include
 *****************************************************************************/
#include "MMIDataType.h"

#include "WriteResUtil.h"

/***************************************************************************** 
 * Define
 *****************************************************************************/
 /* 1 MB input bitmap file size limit */
#define ABMENC_BMP_FILE_BUFFER_SIZE     (8 * 1024 * 2048)

#define ABM_ENC_MAX_FILE_SIZE           0xffffffff

/* abm encoder option flags, encoder will return smallest selected format */
/* Original file format */
#define ABM_ENC_OPTION_FLAG_ORIGINAL    (1 << 0)
/* ABM file format */
#define ABM_ENC_OPTION_FLAG_ABM         (1 << 1)
/* ABM file format */    
#define ABM_ENC_OPTION_FLAG_AB2         (1 << 2)
/* 24-bit format */    
#define ABM_ENC_OPTION_FLAG_24BIT       (1 << 3)
/* All file format enable */
#define ABM_ENC_OPTION_FLAG_ALL         (ABM_ENC_OPTION_FLAG_ORIGINAL | ABM_ENC_OPTION_FLAG_ABM | ABM_ENC_OPTION_FLAG_AB2)


/***************************************************************************** 
 * Typedef
 *****************************************************************************/
/* abm encoder return code */
typedef enum
{
    ABMENC_UNIT_TEST_FAILED = -1,       /* unit test failed */
    ABMENC_UNIT_TEST_SUCCESSFUL = 0,    /* unit test successful */

    ABM_ENC_INPUT_BITMAP_ERROR = -2,    /* input bitmap error */
    ABMENC_COLOR_NOT_FOUND = -1,        /* color not found in the color table */
    
    ABM_ENC_RETURN_KEEP_ORIGINAL = 0,   /* do not use ABM */
    ABM_ENC_RETURN_USE_ABM,             /* use ABM */
    ABM_ENC_RETURN_USE_AB2,             /* use ABMv2 */
    
    ABM_ENC_OK                          /* ABM internal use successful code */
} abm_enc_return_value;

typedef U32 abm_enc_option_flag_type;


/***************************************************************************** 
 * Global Function
 *****************************************************************************/
extern S32 ABM_load(
        U8  *in_bmp_filename,
        S32 dev_bmp_bpp,
        U8  image_type,
        abm_enc_option_flag_type option,
        U8  *data,
        S32 *size,
        S32 *width,
        S32 *height,
        MMI_BOOL is9slice,
        SetImageProcessData * processData);

extern S32 ABMLoader(U8 *in_filename, U8 *out_filename, S32 encode_option, MMI_BOOL is9slice, U8* _9slice_filename, SetImageProcessData * processData);
extern S32 is16BitBMP(U8  *in_bmp_filename);
#endif /* __ABMLOADER_H__ */
