/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#ifdef __cplusplus
extern "C" {
#endif

#include "MMI_features.h"
#include "app_mem.h"
#include "app_mem_config.h"

#ifdef __MTK_TARGET__
#define ALIGN(n) __align(n)  //target alignment
#else
#define ALIGN(n)  __declspec(align(n)) //modis alignment
#endif

/* memory pool */
#ifdef __MTK_TARGET__
#ifdef __DYNAMIC_SWITCH_CACHEABILITY__
#pragma arm section zidata = "DYNAMICCACHEABLEZI_C_MMIPOOL"
#else
#pragma arm section zidata = "LARGEPOOL_FIRST_ZI"
#endif
#endif /* __MTK_TARGET__ */

#if APPLIB_MEM_AP_POOL_ALIGN > 0
/* 
 * There is an ARM ADS issue.
 * 
 * If APPLIB_MEM_AP_POOL_SIZE is 1.2MB and __align(512*1024),
 * the pool g_applib_mem_ap_pool[] will take 1.5MB. 
 *
 * As a result, we do not set __align here. Instead, the alignment
 * is configured in the scatter files.
 *
 * (Note: this issue no longer exists in ARM RVCT)
 */
// __align(APPLIB_MEM_AP_POOL_ALIGN)
#endif

/* Use kal_uint32 to be 4-byte aligned */
#if defined __MMI_USE_MMV2__
    #define AP_ASM_USE_SIZE (APPLIB_MEM_AP_POOL_SIZE + 102400)
    KAL_FLMM_VA_ATTRIBUTE U8 g_applib_mem_ap_va_pool[AP_ASM_USE_SIZE*4]    ;
    KAL_FLMM_PA_ATTRIBUTE U8 g_applib_mem_ap_pool[AP_ASM_USE_SIZE+FLMM_CONFIG_OVERHEAD(AP_ASM_USE_SIZE)]    ;
#else
ALIGN(ASM_ALIGN_SIZE)  U8 g_applib_mem_ap_pool[APPLIB_MEM_AP_POOL_SIZE + 10240];
#endif

U32 mmi_res_get_asm_pool_size()
{
    return sizeof(g_applib_mem_ap_pool);
}

void* mmi_res_get_asm_pool()
{
    return (void*)g_applib_mem_ap_pool;
}

#if defined __MMI_USE_MMV2__
U32 mmi_res_get_asm_pool_va_size()
{
    return sizeof(g_applib_mem_ap_va_pool);
}

void* mmi_res_get_asm_va_pool()
{
    return (void*)g_applib_mem_ap_va_pool;
}


U32 mmi_res_get_asm_pool_size_wo_flmm_overhead()
{
    return sizeof(g_applib_mem_ap_pool) - FLMM_CONFIG_OVERHEAD(AP_ASM_USE_SIZE);
}
#endif

#ifdef __cplusplus
}
#endif
