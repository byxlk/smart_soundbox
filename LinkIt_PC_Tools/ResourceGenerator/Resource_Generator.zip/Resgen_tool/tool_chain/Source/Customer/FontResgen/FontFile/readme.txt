Please copy the generated files to the project folder and add them into the project makefile:

1) source file: 
For example, Fontres.c, put it under the path project/[chip]/apps/[project]/src/resource/
Add this line in the Makefile:
C_FILES += $(APP_PATH_SRC)/resource/FontRes.c

2) header file: 
For example, L_English_small.h, put it under the path project/[chip]/apps/[project]/inc/resource/
Add this line in the Makefile:
CFLAGS += -I$(SOURCE_DIR)/$(APP_PATH)/inc/resource
