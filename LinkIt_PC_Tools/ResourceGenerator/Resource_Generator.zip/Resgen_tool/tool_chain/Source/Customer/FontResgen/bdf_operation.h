/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */

#if !defined(MMI_FONT_BDF_OPERATION_H)
#define MMI_FONT_BDF_OPERATION_H

#include "font_resgen_data_struct.h"
 

class CBdfOperation
{
public:
	//bool		m_bEquiDistant;
    MCTFontInfo m_struFontInfo;
    S32		    m_nBBox;
	S32		    m_nBBoy;
	S32		    m_nOrgHtOffset;
	S32		    m_nOrgWidthOffset;
	int			m_iswidth1, m_iswidth2;
	int			m_idwidth1, m_idwidth2;
	U32		    m_nDWidth;
	U32		    m_nByteArraySize;	
	U32		    m_nTotalChars ;
	U32		    m_nWidth;
	U32		    m_nHeight;
	S32		    m_nCurrCharHt;
	S32		    m_nCurrCharWidth;
	U32		    m_nIndexArray;      /* raw data byte count */
    
	S32		    m_nBoxMaxWidth;

	//Ascent and Descent
	int			m_nAscent;
	int			m_nDescent;
   
    string  m_strLanguageName;
    string  m_bdf_filename;
    string  m_bdf_filepath;
    
    U8      m_fontDataIndex;
    bool    m_isfixed;
    U8      m_bGenerateDWidth;

	bool parsing_bdf_file(string *bdf_file, U8 fontDataIndex, bool isfixed);
	bool LoadBDFFile(sMCTCustFontData *font_data);
    void GetRangesFromBDF(string *bdf_file, U32 **pRange, 
										   sMCTRangeDetails **pRangeDetails, 
										   string  rangeInfoName, 
										   string  rangeDataName, 
										   string  rangeOffsetName, 
										   string  fontRangeOffsetStructName,
										   bool fixWidth, U8 charBytes);
    int font_convert(int encoding1, int bbx1, int bbx2, MCTFontInfo *pMMIFont,
									  U64 *stream, int nCount, int nCountCompression);
    void parsing_stream(U64 *pStream, MCTFontInfo *pMMIFont, int nIndex, int nSize, int charsize);
    U64  ReverseBitOrdering(U64 nNumber, int nSize);
    bool release_parsing_bdf_file_alloc_buffer(U8 fontDataIndex);
    
    CBdfOperation(string *language_name, U8 fontDataIndex, bool isfixed, string *pbdf_file, U8 is_dwidth);
    ~CBdfOperation();
};





#endif