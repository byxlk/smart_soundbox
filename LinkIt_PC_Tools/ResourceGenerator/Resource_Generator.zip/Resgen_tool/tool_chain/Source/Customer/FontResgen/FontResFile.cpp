/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */

#include "stdafx.h"
#include "FontResFile.h"
#include "FontClass.h"
#include "FontHWCompress.h"




/*****************************************************************************
 * FUNCTION
 *  font_16HexStringToInt
 * DESCRIPTION
 *  
 * PARAMETERS
 *  outputPath [IN]
 * RETURNS
 *  
******************************************************************************/
int font_16HexStringToInt(string *str)
{
    string hexstr = *str;
    char num = 0;
    int res = 0;
    int bit = 1;
    for(int i = hexstr.length() - 1; i >= 0; i--)
    {
        if((hexstr[i] >= '0') && (hexstr[i] <= '9'))
        {
            num = hexstr[i] - '0';
        }
        else if((hexstr[i] >= 'A') && (hexstr[i] <= 'F'))
        {
            num = hexstr[i] - 'A' + 10;
        }
        else if((hexstr[i] >= 'a') && (hexstr[i] <= 'f'))
        {
            num = hexstr[i] - 'a' + 10;
        }
        else
        {
            return 0;
        }
        res = res + num * bit;
        bit = bit * 16;
    }
    return res;
}


/*****************************************************************************
 * FUNCTION
 *  font_AddLanguageFlagToString
 * DESCRIPTION
 *  
 * PARAMETERS
 *  outputPath [IN]
 * RETURNS
 *  
******************************************************************************/
bool font_AddLanguageFlagToString(string * str, char lang_flag)
{
    /*----------------------------------------------------------------*/
    /* Local Variables                                                */
    /*----------------------------------------------------------------*/
    string hexstr;
    char temp[9] = {0};
    int num = font_16HexStringToInt(&hexstr);

    /*----------------------------------------------------------------*/
    /* Code Body                                                      */
    /*----------------------------------------------------------------*/
    if(((*str)[0] == '0') && (((*str)[1] == 'x') || ((*str)[1] == 'X')))
    {
       hexstr = str->substr(2);
    }

    num |= (1 << (lang_flag - 1));
    sprintf(temp, "0X%08X", num);
    *str = (char *)temp;
    return true;
}


/*****************************************************************************
 * FUNCTION
 *  GenerateFontResFile
 * DESCRIPTION
 *  This function is used to create FontRes.c file.
 * PARAMETERS
 *  outputPath [IN]
 * RETURNS
 *  
******************************************************************************/
void FontGenFile::GenerateFontResFile(FontEngine *font_engine)
{
    /*----------------------------------------------------------------*/
    /* Local Variables                                                */
    /*----------------------------------------------------------------*/
    FILE *pFile;
    FILE *pFile_language_config;
    string str;
    char cTemp[100] ={0};
    char Temp1[100] ={0};

    /*----------------------------------------------------------------*/
    /* Code Body                                                      */
    /*----------------------------------------------------------------*/

    if(pFile = fopen(string(m_outputPath + ("\\") + FONT_RES_FILENAME).c_str(), ("w")))
    {	
        fputs(_T("/* Copyright Statement:\n"),pFile);
        fputs(_T(" *\n"),pFile);
        fputs(_T(" * (C) 2005-2016  MediaTek Inc. All rights reserved.\n"),pFile);
        fputs(_T(" *\n"),pFile);
        fputs(_T(" * This software/firmware and related documentation (\"MediaTek Software\") are\n"),pFile);
        fputs(_T(" * protected under relevant copyright laws. The information contained herein\n"),pFile);
        fputs(_T(" * is confidential and proprietary to MediaTek Inc. (\"MediaTek\") and/or its licensors.\n"),pFile);
        fputs(_T(" * Without the prior written permission of MediaTek and/or its licensors,\n"),pFile);
        fputs(_T(" * any reproduction, modification, use or disclosure of MediaTek Software,\n"),pFile);
        fputs(_T(" * and information contained herein, in whole or in part, shall be strictly prohibited.\n"),pFile);
        fputs(_T(" * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software\n"),pFile);
        fputs(_T(" * if you have agreed to and been bound by the applicable license agreement with\n"),pFile);
        fputs(_T(" * MediaTek (\"License Agreement\") and been granted explicit permission to do so within\n"),pFile);
        fputs(_T(" * the License Agreement (\"Permitted User\").  If you are not a Permitted User,\n"),pFile);
        fputs(_T(" * please cease any access or use of MediaTek Software immediately.\n"),pFile);
        fputs(_T(" * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES\n"),pFile);
        fputs(_T(" * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES\n"),pFile);
        fputs(_T(" * ARE PROVIDED TO RECEIVER ON AN \"AS-IS\" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL\n"),pFile);
        fputs(_T(" * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF\n"),pFile);
        fputs(_T(" * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.\n"),pFile);
        fputs(_T(" * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE\n"),pFile);
        fputs(_T(" * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR\n"),pFile);
        fputs(_T(" * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH\n"),pFile);
        fputs(_T(" * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES\n"),pFile);
        fputs(_T(" * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES\n"),pFile);
        fputs(_T(" * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK\n"),pFile);
        fputs(_T(" * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR\n"),pFile);
        fputs(_T(" * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND\n"),pFile);
        fputs(_T(" * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,\n"),pFile);
        fputs(_T(" * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,\n"),pFile);
        fputs(_T(" * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO\n"),pFile);
        fputs(_T(" * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.\n"),pFile);
        fputs(_T(" */\n"),pFile);
        fputs(_T("#include \"gdi_font_resource.h\"\n"),pFile);
        fputs(_T("#include \"gdi_font_engine.h\"\n"),pFile);
        //fputs(_T("#include \"MMI_features.h\"\n"),pFile);
        //fputs(_T("#include \"vector_font_lang_memory_card_config.h\"\n"),pFile);


        pFile_language_config = fopen(string(".\\language_config.h").c_str(), ("r"));
        while ( fgets(Temp1, 100, pFile_language_config ) != NULL)
        {
            fprintf(pFile,_T("%s"), Temp1);  
        }
        fputs(_T("\n#ifndef NULL\n"),pFile);
        fputs(_T("#define NULL  (void *)0           /*  NULL    :   Null pointer */\n"),pFile);
        fputs(_T("#endif\n"),pFile);
		
      
        fputs(_T("\n#define  MAX_LANGUAGES     30\n"), pFile);

     
        /* include font data file */
        if(font_engine != NULL)
        {
            for(int i = 0; i < MCT_MAX_FONT_TYPES; i++)
            {
                vector<FontData_Info> *pvctr = &(font_engine->m_font_family[i].fontData_contain); 
                vector<FontData_Info>::iterator it;
                for (it = pvctr->begin(); it < pvctr->end(); it++)
                {
                    if(font_engine->CompareInFontFamily(it) != 2)
                    {
                        fputs("\n#include \"", pFile);
                        fputs(it->gen_hfile_name.c_str(), pFile);
                        fputs("\"", pFile);
                    }
                }
            } 
        }

        fputs("\n", pFile);
        GenerateFontResFile_GroupData(font_engine, pFile);

        sprintf(cTemp, "\nconst uint8_t g_fontfamily_count = %d ;\n", MCT_MAX_FONT_TYPES);
        str = (char *)cTemp;
        fputs(cTemp,pFile);
            
        fputs(("\n"),pFile);	

        if(IsUseFontCompression())
        {
            GenerateCompressionInfo(font_engine, pFile);
        }

        if(IsUseHWFontCompression()) 
        {
            FontHWCompressWriteLVTableToFile(pFile,
                                LV1Size, LV2Size,
                                &LV1Dict1, &LV1Dict2,
                                lv1_table_name,
                                lv2_table_name); 
        }
        

        GenerateFontResLanguageTable(&string(""), pFile);

        fclose(pFile);
        
	}
	
}


/*****************************************************************************
 * FUNCTION
 *  GenerateFontResFile
 * DESCRIPTION
 *  This function is used to create FontRes.c file.
 * PARAMETERS
 *  outputPath [IN]
 * RETURNS
 *  
******************************************************************************/
void FontGenFile::GenFontGroupString(FontEngine *font_engine, U8 font_size, FILE *p_file)
{
    /*----------------------------------------------------------------*/
    /* Local Variables                                                */
    /*----------------------------------------------------------------*/
    string str;

    /*----------------------------------------------------------------*/
    /* Code Body                                                      */
    /*----------------------------------------------------------------*/
    font_group_struct *pgroup = &(font_engine->m_font_family[font_size]);
    if(pgroup->nTotalFonts == 0)
    {
        str = "NULL\n";
        fputs(str.c_str(), p_file);
    }
    else
    {
        for(int i = 0; i < pgroup->nTotalFonts; i++)
        {
            str = "&" + pgroup->fontData_contain[i].font_data_name;
            if(i != pgroup->nTotalFonts - 1)
            {
                str += ",\n";
            }
            else
            {
                str += "\n";
            }
                fputs(str.c_str(), p_file);
        }
    }

     
}


/*****************************************************************************
 * FUNCTION
 *  GenerateFontResFile
 * DESCRIPTION
 *  This function is used to create FontRes.c file.
 * PARAMETERS
 *  outputPath [IN]
 * RETURNS
 *  
******************************************************************************/
void FontGenFile::GenerateFontResFile_GroupData(FontEngine *font_engine, FILE *pFile)
{
    /*----------------------------------------------------------------*/
    /* Local Variables                                                */
    /*----------------------------------------------------------------*/
    char cTemp[100] = {0};
    int i = 0;   
    
    /*----------------------------------------------------------------*/
    /* Code Body                                                      */
    /*----------------------------------------------------------------*/
    for(i = 0; i < MCT_MAX_FONT_TYPES; i++)
    {    
        fputs(("\n"),pFile);
        switch(i)
        {
            case MCT_ALPHA_SMALL_FONT:
            {
                fputs(("const sCustFontData * const g_small_font_data_array[] = {\n"),pFile);
                GenFontGroupString(font_engine, i, pFile);
                fputs(("}; \n"),pFile); 
                break;
            }
            case MCT_ALPHA_MEDIUM_FONT:
            {
                fputs(("const sCustFontData * const g_medium_font_data_array[] = {\n"),pFile);
                GenFontGroupString(font_engine, i, pFile);
                fputs(("}; \n"),pFile);  
                break;
            }
            case MCT_ALPHA_LARGE_FONT:
            {
                fputs(("const sCustFontData * const g_large_font_data_array[] = {\n"),pFile);
                GenFontGroupString(font_engine, i, pFile);
                fputs(("}; \n"),pFile); 
                break;
                
            }
            case MCT_ALPHA_SUBLCD_FONT:
            {
                fputs(("const sCustFontData * const g_sublcd_font_data_array[] = {\n"),pFile);
                GenFontGroupString(font_engine, i, pFile);
                fputs(("}; \n"),pFile); 
                break;
            }
            case MCT_ALPHA_DIALER_FONT:
            {
                fputs(("const sCustFontData * const g_dialling_font_data_array[] = {\n"),pFile);
                GenFontGroupString(font_engine, i, pFile);
                fputs(("}; \n"),pFile);  
                break;
            }
            case MCT_ALPHA_NUMBER1_FONT:
            {
                fputs(("const sCustFontData * const g_number1_font_data_array[] = {\n"),pFile);
                GenFontGroupString(font_engine, i, pFile);
                fputs(("}; \n"),pFile);  
                break;
            }
            case MCT_ALPHA_NUMBER2_FONT:
            {
                fputs(("const sCustFontData * const g_number2_font_data_array[] = {\n"),pFile);
                GenFontGroupString(font_engine, i, pFile);
                fputs(("}; \n"),pFile);  
                break;
            }
            case MCT_ALPHA_TOUCH_SCREEN_FONT:
            {
                fputs(("const sCustFontData * const g_touchscreen_font_data_array[] = {\n"),pFile);
                GenFontGroupString(font_engine, i, pFile);
                fputs(("}; \n"),pFile); 
                break;
            }
            case MCT_ALPHA_TOUCH_SCREEN_LAREG_FONT:
            {
                fputs(("const sCustFontData * const g_touchscreen_large_font_data_array[] = {\n"),pFile);
                GenFontGroupString(font_engine, i, pFile);
                fputs(("}; \n"),pFile);  
                break;
            }
                                                                        
        }
        
    }
    
    fputs(("\nconst font_group_struct g_fontfamily[MAX_FONT_SIZE] = {\n"),pFile);
    for(i = 0; i < MCT_MAX_FONT_TYPES; i++)
    {
        switch(i)
        {
            case MCT_ALPHA_SMALL_FONT:
            {
                sprintf((char *)cTemp, "{%d, g_small_font_data_array},", font_engine->m_font_family[i].nTotalFonts);
                break;
            }
            case MCT_ALPHA_MEDIUM_FONT:
            {
                fputs(("\n"),pFile); 
                sprintf((char *)cTemp, "{%d, g_medium_font_data_array},", font_engine->m_font_family[i].nTotalFonts);
                break;
            }
            case MCT_ALPHA_LARGE_FONT:
            {
                fputs(("\n"),pFile); 
                sprintf((char *)cTemp, "{%d, g_large_font_data_array},", font_engine->m_font_family[i].nTotalFonts);
                break;
                
            }
            case MCT_ALPHA_SUBLCD_FONT:
            {
                fputs(("\n"),pFile); 
                sprintf((char *)cTemp, "{%d, g_sublcd_font_data_array},", font_engine->m_font_family[i].nTotalFonts);
                break;
            }
            case MCT_ALPHA_DIALER_FONT:
            {
                fputs(("\n"),pFile); 
                sprintf((char *)cTemp, "{%d, g_dialling_font_data_array},", font_engine->m_font_family[i].nTotalFonts);  
                break;
            }
            case MCT_ALPHA_NUMBER1_FONT:
            {
                fputs(("\n"),pFile); 
                sprintf((char *)cTemp, "{%d, g_number1_font_data_array},", font_engine->m_font_family[i].nTotalFonts);
                break;
            }
            case MCT_ALPHA_NUMBER2_FONT:
            {
                fputs(("\n"),pFile); 
                sprintf((char *)cTemp, "{%d, g_number2_font_data_array},", font_engine->m_font_family[i].nTotalFonts);  
                break;
            }
            case MCT_ALPHA_TOUCH_SCREEN_FONT:
            {
                fputs(("\n"),pFile); 
                sprintf((char *)cTemp, "{%d, g_touchscreen_font_data_array},", font_engine->m_font_family[i].nTotalFonts);
                break;
            }
            case MCT_ALPHA_TOUCH_SCREEN_LAREG_FONT:
            {
                fputs(("\n"),pFile); 
                sprintf((char *)cTemp, "{%d, g_touchscreen_large_font_data_array},", font_engine->m_font_family[i].nTotalFonts);
                break;
            }
        }     
        fputs(cTemp, pFile);
    }
    fputs(("\n};"),pFile);    
         
}

/*****************************************************************************
 * FUNCTION
 *  GenerateCompressionInfo
 * DESCRIPTION
 *  
 * PARAMETERS
 *  outputPath [IN]
 * RETURNS
 *  
******************************************************************************/
bool FontGenFile::GenerateCompressionInfo(FontEngine *font_engine, FILE *pFile)
{
    FILE *compress_info_file = NULL;
    char	temp[100] = {0};
    
    if(IsUseFontCompression())
    {
        if(compress_info_file = fopen(string(font_engine->m_outputPath + "\\" +  FONT_COMPRESSION_INFO_NAME).c_str(), ("r")))
        {
            fprintf(pFile,_T("\n\n#if defined(__MMI_FONT_COMPRESSION__)"));
            fputs(_T("\nconst mmi_font_compress_info mtk_font_compress_info[] = {"),pFile);
            while ( fgets(temp, 100, compress_info_file ) != NULL)
            {
               fprintf(pFile,_T("%s"), temp);  
            }
            fprintf(pFile,_T("\n  {NULL, 0, NULL, 0}\n")); 
            fprintf(pFile, _T("};\n"));
            fprintf(pFile,_T("\n#endif\n"));
            fclose(compress_info_file);
            return true;
        } 
    }
    return false;
}


/*****************************************************************************
 * FUNCTION
 *  GenerateFontDataFile
 * DESCRIPTION
 *  
 * PARAMETERS
 *  outputPath [IN]
 * RETURNS
 *  
******************************************************************************/
bool FontGenFile::GenerateFontDataFile(sMCTCustFontData *font_data)
{
    U32 iCount = 0;  
    FILE*		pFile = NULL;
    FILE* 		pFile_data = NULL;
    if((font_data == NULL))
    {
        return false;
    }
    if(pFile = fopen(string(m_outputPath + "\\" + font_data->gen_hfile_name).c_str(), ("w")))
    {
        fputs(_T("/* Copyright Statement:\n"),pFile);
	    fputs(_T(" *\n"),pFile);
	    fputs(_T(" * (C) 2005-2016  MediaTek Inc. All rights reserved.\n"),pFile);
	    fputs(_T(" *\n"),pFile);
	    fputs(_T(" * This software/firmware and related documentation (\"MediaTek Software\") are\n"),pFile);
	    fputs(_T(" * protected under relevant copyright laws. The information contained herein\n"),pFile);
	    fputs(_T(" * is confidential and proprietary to MediaTek Inc. (\"MediaTek\") and/or its licensors.\n"),pFile);
	    fputs(_T(" * Without the prior written permission of MediaTek and/or its licensors,\n"),pFile);
	    fputs(_T(" * any reproduction, modification, use or disclosure of MediaTek Software,\n"),pFile);
	    fputs(_T(" * and information contained herein, in whole or in part, shall be strictly prohibited.\n"),pFile);
	    fputs(_T(" * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software\n"),pFile);
	    fputs(_T(" * if you have agreed to and been bound by the applicable license agreement with\n"),pFile);
	    fputs(_T(" * MediaTek (\"License Agreement\") and been granted explicit permission to do so within\n"),pFile);
	    fputs(_T(" * the License Agreement (\"Permitted User\").  If you are not a Permitted User,\n"),pFile);
	    fputs(_T(" * please cease any access or use of MediaTek Software immediately.\n"),pFile);
	    fputs(_T(" * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES\n"),pFile);
	    fputs(_T(" * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES\n"),pFile);
	    fputs(_T(" * ARE PROVIDED TO RECEIVER ON AN \"AS-IS\" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL\n"),pFile);
	    fputs(_T(" * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF\n"),pFile);
	    fputs(_T(" * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.\n"),pFile);
	    fputs(_T(" * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE\n"),pFile);
	    fputs(_T(" * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR\n"),pFile);
	    fputs(_T(" * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH\n"),pFile);
	    fputs(_T(" * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES\n"),pFile);
	    fputs(_T(" * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES\n"),pFile);
	    fputs(_T(" * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK\n"),pFile);
	    fputs(_T(" * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR\n"),pFile);
	    fputs(_T(" * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND\n"),pFile);
	    fputs(_T(" * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,\n"),pFile);
	    fputs(_T(" * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,\n"),pFile);
	    fputs(_T(" * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO\n"),pFile);
	    fputs(_T(" * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.\n"),pFile);
	    fputs(_T(" */\n"),pFile);  
        if(IsUseFontCompression())
        {
            fprintf(pFile,_T("\n#if defined(__MMI_FONT_COMPRESSION__)\n"));

            if((font_data->nEquiDistant) == false)
            {                                
                /* font data width array */
                fprintf(pFile, _T("\nconst uint8_t %s[%ld]= {"),font_data->fontWidthName, font_data->m_nTotalChars);
                for( iCount = 0 ; iCount < font_data->m_nTotalChars; iCount++)
                { 
                    if (iCount%16 == 0)
                    {
                        fprintf(pFile, _T("\n"));
                    }    
                    fprintf(pFile, _T("0x%-2X,"), font_data->pWidthArray[iCount]);        
                }
                fprintf(pFile,_T("};\n"));
                
                /* font data Dwidth array */
                if(font_data->is_dwidth)
                {
                    fprintf(pFile, ("\nconst uint8_t %s[%ld]= {"), font_data->fontDWidthName,font_data->m_nTotalChars);
                    for( iCount = 0 ; iCount < font_data->m_nTotalChars; iCount++)
                    {
                        if (iCount%16 == 0)
                        {
                            fprintf(pFile, _T("\n"));               
                        }                    
                        fprintf(pFile, _T("0x%-2X,"), font_data->pDWidthArray[iCount]);        
                    }
                    fprintf(pFile,_T("};\n"));
                }

                /* font data index array (offset)  */
                fprintf(pFile, _T("\nconst uint8_t %s[%ld]= {"),font_data->fontOffsetName, font_data->m_nTotalChars + 1);
                for( iCount = 0 ; iCount < font_data->m_nTotalChars + 1; iCount++)
                {
                    if (iCount%16 == 0)
                    {
                       fprintf(pFile,_T("\n"));   
                    }  
                    
                    /* Split to several block per 64k, so adjust value data offset table.  */
                    char a[10];
                    int index_value = font_data->pOffsetArray[iCount];
                    index_value = index_value % FONT_ENGINE_DATA_BLOCK_SIZE;  
                    sprintf(a,_T("0x%02X,"), index_value);

                    fprintf(pFile, a);
                }
                fprintf(pFile,_T("};\n"));
                
            }

            /* range offset */
            fprintf(pFile, _T("\nconst uint16_t %s[%ld]= {"),
                                font_data->pRangeDetails->rangeOffsetName, 
                                font_data->pRangeDetails->nNoOfRanges);
             
            U32 tempvalue;
            for( iCount = 0 ; iCount < font_data->pRangeDetails->nNoOfRanges; iCount++)
            {
                if (iCount%16 == 0)
                {
                    fprintf(pFile, _T("\n"));     
                }                            
                char a[10];
                tempvalue = font_data->pRange[iCount];      
                sprintf(a,_T("%ld,"),  tempvalue);
                fprintf(pFile, a);
            }
            fprintf(pFile,_T("};\n"));  


            /* Font Data */           
            fprintf(pFile,_T("\nconst uint8_t  %s[%ld]= {"), 
                font_data->fontCompressedDataName,
                font_data->nDataArrayCompressionSize);
            for( iCount = 0 ; iCount < font_data->nDataArrayCompressionSize; iCount++)
            {
                if (iCount%16 == 0)
                {
                    fprintf(pFile, ("\n"));  
                }
                fprintf(pFile, ("0x%X,"), font_data->pDataArrayCompression[iCount]);
            }
            fprintf(pFile, ("};\n"));

            fprintf(pFile,_T("\n#if !defined(__MMI_BDF_SW_COMPRESSION__) \n"));
            
            /* RangeBlockIndex */
            if(font_data->nEquiDistant == false)
            { 
                
                fprintf(pFile,_T("\nconst uint16_t %s[%ld]= {"),
                    font_data->pRangeDetails->fontRangeBlockIndexArrayName,
                    font_data->nBlockIndexArrayCompressionSize+1);
                //{264},       // <= how many character are involved in the block and its previous block
                for(iCount=0; iCount<= font_data->nBlockIndexArrayCompressionSize; iCount++)
                {
                    if(iCount%16 ==0)
                    {
                        fprintf(pFile, _T("\n")); 
                    }
                    fprintf(pFile, _T("%ld,"), font_data->pBlockIndexArrayCompression[iCount]);
                }
                fprintf(pFile,_T("\n};\n"));
            }
            
            /* mmi font range offset struct */
            fprintf(pFile, _T("\nconst mmi_font_range_offset_struct %s = {"),  
                  font_data->pRangeDetails->fontRangeOffsetStructName);
            
            
            if(font_data->nEquiDistant== false)
            {
                //1,           // <= how many block that the data is devided into blocks with size 64KB
                int block_number = font_data->nDataArraySize;
                if(block_number % FONT_ENGINE_DATA_BLOCK_SIZE)  
                {
                    block_number = block_number / FONT_ENGINE_DATA_BLOCK_SIZE + 1;                                    
                }
                else
                {
                    block_number = block_number / FONT_ENGINE_DATA_BLOCK_SIZE;
                }
                fprintf(pFile,_T("\n%d,\n"), block_number); 
                //2
                fprintf(pFile, _T("%s,\n"),font_data->pRangeDetails->fontRangeBlockIndexArrayName);    
            }
            else
            {
                fprintf(pFile,_T("\n0,\n"));
                fprintf(pFile,_T("NULL,\n"));
            }
            
            //3
            fprintf(pFile, _T("%s,\n"),font_data->pRangeDetails->rangeOffsetName);   
            fprintf(pFile,_T("};\n"));

            fprintf(pFile,_T("\n#endif  /* endif of  !defined(__MMI_BDF_SW_COMPRESSION__ */\n"));
            
            //empty array
            fprintf(pFile,_T("\nuint8_t  %s[%ld];"), 
                font_data->fontDataName,
                font_data->nDataArraySize);  
           

            fprintf(pFile,_T("\n#else\n"));

        }

        /* uncompression data */

        if((font_data->nEquiDistant) == false)
        {                                
            /* font data width array */
            fprintf(pFile, _T("\nconst uint8_t %s[%ld]= {"),font_data->fontWidthName, font_data->m_nTotalChars);
            for( iCount = 0 ; iCount < font_data->m_nTotalChars; iCount++)
            { 
                if (iCount%16 == 0)
                {
                    fprintf(pFile, _T("\n"));
                }    
                fprintf(pFile, _T("0x%-2X,"), font_data->pWidthArray[iCount]);        
            }
            fprintf(pFile,_T("};\n"));
            
            /* font data Dwidth array */
            if(font_data->is_dwidth)
            {
                fprintf(pFile, ("\nconst uint8_t %s[%ld]= {"), font_data->fontDWidthName,font_data->m_nTotalChars);
                for( iCount = 0 ; iCount < font_data->m_nTotalChars; iCount++)
                {
                    if (iCount%16 == 0)
                    {
                        fprintf(pFile, _T("\n"));               
                    }                    
                    fprintf(pFile, _T("0x%-2X,"), font_data->pDWidthArray[iCount]);        
                }
                fprintf(pFile,_T("};\n"));
            }

        }

        /* If hardware compress, Data offset is necessary. */
        if(IsUseHWFontCompression())
        {
            /* font data index array (offset)  */
            fprintf(pFile,_T("\n#if defined(__MMI_BDF_SW_COMPRESSION__)\n"));
            
            fprintf(pFile, _T("\nconst uint8_t %s[%ld]= {"),font_data->fontOffsetName, font_data->m_nTotalChars + 1);
            for( iCount = 0 ; iCount < font_data->m_nTotalChars + 1; iCount++)
            {
                if (iCount%16 == 0)
                {
                   fprintf(pFile,_T("\n"));   
                }  
                
                /* Split to several block per 64k, so adjust value data offset table.  */
                char a[10];
                int index_value = font_data->pOffsetArray[iCount];
                index_value = index_value % FONT_ENGINE_DATA_BLOCK_SIZE;  
                sprintf(a,_T("0x%02X,"), index_value);

                fprintf(pFile, a);
            }
            fprintf(pFile,_T("};\n"));
            fprintf(pFile, "\n#endif\n");
        }
        else if(font_data->nEquiDistant == false)
        {
            /* font data index array (offset)  */
            fprintf(pFile, _T("\nconst uint32_t %s[%ld]= {"), font_data->fontOffsetName,  font_data->m_nTotalChars + 1);
            for( iCount = 0 ; iCount < font_data->m_nTotalChars+1; iCount++)
            {
                if (iCount%16 == 0)
                {
                    fprintf(pFile,_T("\n"));    
                }                             
                char a[10];
                sprintf(a, _T("0x%04X,"),  font_data->pOffsetArray[iCount]);
                fprintf(pFile, a);
            }
            fprintf(pFile,_T("};\n"));    
        }

        /* RangeOffset */
        fprintf(pFile, _T("\nconst uint16_t %s[%ld]= {"),
                            font_data->pRangeDetails->rangeOffsetName, 
                            font_data->pRangeDetails->nNoOfRanges);
        
        for( iCount = 0 ; iCount < font_data->pRangeDetails->nNoOfRanges; iCount++)
        {
            if (iCount%16 == 0)
            {
                fprintf(pFile, _T("\n"));  
            }
                                               
            char a[10];
            sprintf(a,_T("%ld,"),  font_data->pRange[iCount]);
            fprintf(pFile, a);
        }                
        fprintf(pFile,_T("};\n"));

        /* Font data */
		if(IsUseFontGroupCompression())
		{
			pFile_data = fopen(string(m_outputPath + ("\\") + FONT_DATA_FILENAME).c_str(), ("a"));
			fprintf(pFile,("\nextern const uint8_t %s[];\n"), font_data->fontDataName);
			if(pFile_data)
			{
				fprintf(pFile_data,("\nconst unsigned char %s[%ld]= {"), font_data->fontDataName,font_data->nDataArraySize);
		        for( iCount = 0 ; iCount < font_data->nDataArraySize; iCount++)
		        {
		            if (iCount%16 == 0)
		            {
		                fprintf(pFile_data, ("\n"));  
		            }
		            fprintf(pFile_data, _T("0x%X,"), font_data->pDataArray[iCount]);
		        }
		        fprintf(pFile_data, ("};\n"));
			}
			
			if(pFile_data)
				fclose(pFile_data);
		}
		else
		{
        fprintf(pFile,("\nconst uint8_t  %s[%ld]= {"), font_data->fontDataName,font_data->nDataArraySize);
        for( iCount = 0 ; iCount < font_data->nDataArraySize; iCount++)
        {
            if (iCount%16 == 0)
            {
                fprintf(pFile, ("\n"));  
            }
            fprintf(pFile, _T("0x%X,"), font_data->pDataArray[iCount]);
        }
        fprintf(pFile, ("};\n"));   
		}

        if(IsUseFontCompression())
        {
             fprintf(pFile, "\n#endif\n");
        }

        if((IsUseFontCompression()) && (IsUseHWFontCompression()) && (font_data->nEquiDistant == true))
        {
            /* font data index array (offset)  */
            fprintf(pFile,_T("\n#if defined(__MMI_BDF_SW_COMPRESSION__)\n"));
            
            fprintf(pFile, _T("\nconst uint8_t %s[%ld]= {"),font_data->fontOffsetName, font_data->m_nTotalChars + 1);
            for( iCount = 0 ; iCount < font_data->m_nTotalChars + 1; iCount++)
            {
                if (iCount%16 == 0)
                {
                   fprintf(pFile,_T("\n"));   
                }  
                
                /* Split to several block per 64k, so adjust value data offset table.  */
                char a[10];
                int index_value = font_data->pOffsetArray[iCount];
                index_value = index_value % FONT_ENGINE_DATA_BLOCK_SIZE;  
                sprintf(a,_T("0x%02X,"), index_value);

                fprintf(pFile, a);
            }
            fprintf(pFile,_T("};\n"));
            fprintf(pFile, "\n#endif\n");
        }
        
        if(IsUseHWFontCompression())
        {
            fprintf(pFile,_T("\n#if defined(__MMI_BDF_SW_COMPRESSION__) \n"));
             /* RangeBlockIndex */
            fprintf(pFile,_T("\nconst uint16_t %s[%ld]= {"),
                font_data->pRangeDetails->fontRangeBlockIndexArrayName,
                font_data->nBlockIndexArrayCompressionSize+1);
            
            for(iCount=0; iCount<= font_data->nBlockIndexArrayCompressionSize; iCount++)
            {
                if(iCount%16 ==0)
                {
                    fprintf(pFile, _T("\n")); 
                }
                fprintf(pFile, _T("%ld,"), font_data->pBlockIndexArrayCompression[iCount]);
            }
            fprintf(pFile,_T("\n};\n"));
            
            /* compression range offset & block struct  */
            fprintf(pFile, _T("\nconst mmi_font_range_offset_struct %s = {"),  
                  font_data->pRangeDetails->fontRangeOffsetStructName);
           
            int block_number;

	    if(IsUseFontGroupCompression())
		block_number = font_data->nDataArrayCompressionSize;
	    else
		block_number = font_data->nDataArraySize;
			
            if(block_number % FONT_ENGINE_DATA_BLOCK_SIZE)  
            {
                block_number = block_number / FONT_ENGINE_DATA_BLOCK_SIZE + 1;                                    
            }
            else
            {
                block_number = block_number / FONT_ENGINE_DATA_BLOCK_SIZE;
            }
            fprintf(pFile,_T("\n%d,\n"), block_number); 
            //2
            fprintf(pFile, _T("%s,\n"),font_data->pRangeDetails->fontRangeBlockIndexArrayName);    

            fprintf(pFile, _T("%s,\n"),font_data->pRangeDetails->rangeOffsetName);   
            fprintf(pFile,_T("};\n"));

            fprintf(pFile, "#endif\n");  
        }
       
        /* Range Data and Range Details */
        GenerateFontResFile_RangeInfo(font_data, pFile);
        if(IsUseFontGroupCompression())
            GenerateFontResFile_GroupInfo(font_data, pFile);

        /* sCustFontData */
        if(IsUseFontCompression())
        {
            fprintf(pFile,_T("\n#if (defined(__MMI_FONT_COMPRESSION__) && !defined(__MMI_BDF_SW_COMPRESSION__)) \n"));
              
            GenerateFontResFile_CustFontData(font_data, pFile, 1);

            fprintf(pFile,_T("\n#else\n"));
        } 

        if(IsUseHWFontCompression())
        {
            GenerateFontResFile_CustFontData(font_data, pFile, 2);  
        }
        else
        {
            GenerateFontResFile_CustFontData(font_data, pFile, 0);  
        }
                            

        if(IsUseFontCompression())
        { 
            fprintf(pFile,_T("\n#endif\n"));
        } 
        
        /* Generate temp file for compression info file */
        if(IsUseFontCompression())
        {
            GenerateCompressionInfoFile(font_data);
        } 
        fclose(pFile); 
        return true;
    }
    return false;     
}


void FontGenFile::GenerateFontResFile_RangeInfo(sMCTCustFontData *font_data, FILE *p_file)
{
    /* Range data */
    fprintf(p_file, ("\nconst RangeData %s[%ld]={\n"), 
            font_data->pRangeDetails->rangeDataName, 
            font_data->pRangeDetails->nNoOfRanges);
        
    for(int k = 0; k < font_data->pRangeDetails->nNoOfRanges; k++ )
    {
        if(k%10==0 && k!=0)
        {
            fputs(_T("\n"), p_file);
        }
        fprintf(p_file,
            "{%ld,%ld},",
            font_data->pRangeDetails->pRangeData[k].nMin,
            font_data->pRangeDetails->pRangeData[k].nMax);
        
    }
    
    fputs(_T("};\n"),p_file);

    /* Range details */
    fprintf(p_file, _T("\nconst RangeDetails %s={\n%ld,\n%s\n};\n"), 
        font_data->pRangeDetails->rangeInfoName, 
        font_data->pRangeDetails->nNoOfRanges, 
        font_data->pRangeDetails->rangeDataName);
     
}


void FontGenFile::GenerateFontResFile_CustFontData(sMCTCustFontData *font_data, FILE *p_file, U8 compress_flag)
{

    /*  CustFontData  */
    fprintf(p_file, _T("\nconst sCustFontData %s = {\n"), font_data->name);
    
    /*  PLUTO_MMI  */
    fprintf(p_file, _T("%ld, %ld,\n%ld, %ld,\n%ld, %ld, %ld,"),
        font_data->nHeight, font_data->nBoxMaxWidth,
        font_data->nAscent, font_data->nDescent,        //Ascent and Descent for baseline
        font_data->nEquiDistant, font_data->nCharBytes, font_data->nMaxChars);
    
    /*  PLUTO_MMI  */
    if(font_data->nEquiDistant == false)
    {
        if(font_data->is_dwidth)
        {
            fprintf(p_file, _T("\n(uint8_t*)%s"), font_data->fontDWidthName);
        }
        else
        {
            fprintf(p_file, _T("\n(uint8_t*)%s"), font_data->fontWidthName);
        }

        if(compress_flag)
        {
            fprintf(p_file, _T(", (uint8_t*)%s, (uint8_t*)%s, (uint8_t*)%s, (mmi_font_range_offset_struct*)&%s,"), 
                font_data->fontWidthName, font_data->fontOffsetName, 
                font_data->fontDataName,  font_data->pRangeDetails->fontRangeOffsetStructName);
        }
        else
        {
            fprintf(p_file, _T(", (uint8_t*)%s, (uint32_t*)%s, (uint8_t*)%s, (uint16_t*)%s,"), 
                font_data->fontWidthName, font_data->fontOffsetName, 
                font_data->fontDataName,  font_data->pRangeDetails->rangeOffsetName);   
        }     
    }       
    else
    {
        if(compress_flag == 1)
        {
            fprintf(p_file, _T("\n(uint8_t*)NULL, (uint8_t*)NULL, (uint8_t*)NULL, (uint8_t*)%s, (mmi_font_range_offset_struct*)&%s,"),
                font_data->fontDataName, font_data->pRangeDetails->fontRangeOffsetStructName);
        }
        else if(compress_flag == 2)
        {
            /* Should add compile option. */
            fprintf(p_file, _T("\n(uint8_t*)NULL, (uint8_t*)NULL, (uint8_t*)%s, (uint8_t*)%s, (mmi_font_range_offset_struct*)&%s,"),
                font_data->fontOffsetName,
                font_data->fontDataName, font_data->pRangeDetails->fontRangeOffsetStructName);
        }
        else 
        {
            fprintf(p_file, _T("\n(uint8_t*)NULL, (uint8_t*)NULL, (uint32_t*)NULL, (uint8_t*)%s, (uint16_t*)%s,"),
                font_data->fontDataName, font_data->pRangeDetails->rangeOffsetName);  
        }
    }    
    fprintf(p_file, ("\n&%s,"), font_data->pRangeDetails->rangeInfoName);
    
    if(IsUseFontGroupCompression())
        fprintf(p_file, ("\n&%s,"), font_data->pRangeDetails->groupInfoName);
    
    MapLanguageWithFontDataFile(font_data, p_file); 

    fprintf(p_file, "\n};\n\n");


}

void FontGenFile::GenerateFontResFile_GroupInfo(sMCTCustFontData *font_data, FILE *p_file)
{
    /* Range data */
    fprintf(p_file, ("\nconst GroupData %s[%ld]={\n"), 
            font_data->pRangeDetails->groupDataName, 
            font_data->pRangeDetails->nNoOfGroup);
        
    for(int k = 0; k < font_data->pRangeDetails->nNoOfGroup; k++ )
    {
        if(k%10==0 && k!=0)
        {
            fputs(_T("\n"), p_file);
        }
        fprintf(p_file,
            "{%ld,%ld},",
            font_data->pRangeDetails->pGroupData[k].nOffset,
            font_data->pRangeDetails->pGroupData[k].nSize);
        
    }
    
    fputs(_T("};\n"),p_file);

    /* Range details */
    fprintf(p_file, _T("\nconst GroupDetails %s={\n%ld,\n%s\n};\n"), 
        font_data->pRangeDetails->groupInfoName, 
        font_data->pRangeDetails->nNoOfGroup, 
        font_data->pRangeDetails->groupDataName);
     
}


/*****************************************************************************
 * FUNCTION
 *  GenerateFontDataFile
 * DESCRIPTION
 *  
 * PARAMETERS
 *  outputPath [IN]
 * RETURNS
 *  
******************************************************************************/
bool FontGenFile::GenerateCompressionInfoFile(sMCTCustFontData *font_data)
{
    U32 iCount = 0;  
    FILE*		pFile = NULL;
    if((font_data == NULL))
    {
        return false;
    }
    if(IsUseFontCompression())
    {
        if(pFile = fopen(string(m_outputPath + "\\" + FONT_COMPRESSION_INFO_NAME).c_str(), ("a+")))       
        {
            fprintf(pFile, _T("\n {%s, %d,%s, %d}, "),
                font_data->fontDataName,
                font_data->nDataArraySize,
                font_data->fontCompressedDataName,
                font_data->nDataArrayCompressionSize); 
            fclose(pFile);
            return true;           
        }      
    }
    return false;
}


/*****************************************************************************
 * FUNCTION
 *  MapLanguageWithFontDataFile
 * DESCRIPTION
 *  
 * PARAMETERS
 *  outputPath [IN]
 * RETURNS
 *  
******************************************************************************/
bool FontGenFile::MapLanguageWithFontDataFile(sMCTCustFontData *font_data, FILE *p_file)
{
    fprintf(p_file, ("\n0X%08X,"), font_data->Language_flags);
    return true;
}


/*****************************************************************************
 * FUNCTION
 *  GenerateFontResLanguageTable
 * DESCRIPTION
 *  
 * PARAMETERS
 *  outputPath [IN]
 * RETURNS
 *  
******************************************************************************/
bool FontGenFile::GenerateFontResLanguageTable(string *readfile_path, FILE *pFile)
{
    FILE *read_file = NULL;
    char temp[FONT_LINE_CHAR] = {0};
    
    if(read_file = fopen(string(FONT_LANGUAGE_TABLE_FILENAME).c_str(), ("r")))       
    {
        printf("[Dependency] %s\n", string(FONT_LANGUAGE_TABLE_FILENAME).c_str());
        while (fgets(temp, FONT_LINE_CHAR, read_file) != NULL)
        {
            fprintf(pFile, temp);
        }
        fclose(read_file);
        return true;           
    }    
    return false;
}



