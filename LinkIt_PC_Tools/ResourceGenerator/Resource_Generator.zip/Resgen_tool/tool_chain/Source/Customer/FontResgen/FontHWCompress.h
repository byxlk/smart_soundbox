/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */

#if !defined(MMI_FONT_HW_COMPRESS_H)
#define MMI_FONT_HW_COMPRESS_H

#include "Font_resgen_data_struct.h"
#include "bmp_font_encode.h"

extern  BF_ENC_STRUCT g_encoder;
extern S32 LV1Size;
extern S32 LV2Size;
extern BF_LEVEL1_TABLE_STRUCT  LV1Dict1;
extern BF_LEVEL2_TABLE_STRUCT  LV1Dict2;

extern const char *lv1_table_name ;
extern const char *lv2_table_name ;

kal_int32 FontHWCompressgenProfileInfo(BF_ENC_STRUCT *pEncoder, 
                                        kal_uint8 *pSrcData,
                                        kal_int32 glyphWidth, 
                                        kal_int32 glyphHeight, 
                                        U32 font_count);

bool FontHWCompressgenProfileInfo(BF_ENC_STRUCT *pEncoder,
                                        U8 *pSrcData, 
                                        U8 width,
                                        U8 height, 
                                        U32 font_count);

bool FontHWCompressEncodeGlyph(BF_ENC_STRUCT *pEncoder, 
                                U8 *pSrcData, U8* w_table, U8 height, 
                                int font_count, U8 *output_data, 
                                int *out_data_len, U8 *output_offset);

BF_ENC_STATUS_ENUM FontHWCompressQueryDictionary( BF_ENC_STRUCT *pEncoder, 
                                    S32 *LV1Size,
                                    S32 *LV2Size,
                                    BF_LEVEL1_TABLE_STRUCT  *LV1Dict,
                                    BF_LEVEL2_TABLE_STRUCT  *LV2Dict);

bool FontHWCompressWriteLVTableToFile(FILE *pFile,
                                    S32 LV1Size,
                                    S32 LV2Size,
                                    BF_LEVEL1_TABLE_STRUCT  *LV1Dict,
                                    BF_LEVEL2_TABLE_STRUCT  *LV2Dict,
                                    const char *lv1_table_name,
                                    const char *lv2_table_name);

int FontLzmaCompress(unsigned char *dest, 
                        size_t *destLen, 
                        const unsigned char *src, 
                        size_t srcLen);

U32 FontLzmaGroupSplitter(U8 *pDataArray, 
                            U32 *pOffsetArray, 
                            U32 nTotalChars, 
                            U8 *pDataArrayCompressed, 
                            S32 *nCompressTotalLen, 
                            sMCTGroupData *sGroupData);

//kal_int32 startEncodeGlyph(BF_ENC_STRUCT *pEncoder, );
#endif