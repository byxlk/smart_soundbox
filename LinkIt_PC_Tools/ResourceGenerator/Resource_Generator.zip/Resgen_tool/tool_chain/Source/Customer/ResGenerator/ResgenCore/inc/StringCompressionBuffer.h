/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */ 
#ifndef __STRING_CONPRESSION_BUFFER_H__
#define __STRING_CONPRESSION_BUFFER_H__

#include <iostream>  
//#include <fstream>  
#include <sstream>  
#include <string>
//#include <map>
#include <vector>
#include "ResgenCatConfig.h"

#define STRING_COMPRESSION_USER_RESERVED_ZI_SIZE "USER_RESERVED_BUFFER_BYTES"
#define STRING_COMPRESSION_USER_RESERVED_ZI_TYPE "U8"
#define STRING_COMPRESSION_USER_RESERVED_ZI_SYMBOL "decompressedReservedSpace"

#define STRING_COMPRESSION_USER_RESERVED_ZI_SIZE "USER_RESERVED_BUFFER_BYTES"
#define STRING_COMPRESSION_USER_RESERVED_ZI_TYPE "U8"
#define STRING_COMPRESSION_USER_RESERVED_ZI_SYMBOL "decompressedReservedSpace"

#define STRING_COMPRESSION_INITIAL_ZI_TYPE "struct StrResStruct"
#define STRING_COMPRESSION_INITIAL_ZI_SYMBOL "StrRes"
#define STRING_COMPRESSION_INITIAL_ZI_SIZE_SYMBOL "mtk_gStrResSize"

#define STRING_COMPRESSION_STRRES_ITEM_TYPE "gdi_resource_custom_string_t"
#define STRING_COMPRESSION_STRMAP_16_ITEM_TYPE "CUSTOM_STRING_MAP_16"
#define STRING_COMPRESSION_STRMAP_32_ITEM_TYPE "gdi_resource_custom_string_map_16_t"

#define STRING_COMPRESSION_GSTRLIST_STRRES_TYPE "gdi_resource_custom_string_t*"
#define STRING_COMPRESSION_GSTRLIST_STRMAP_TYPE "void *"

#define STRING_COMPRESSION_STRRES_ZI_SYMBOL_PREFIX "strRes"
#define STRING_COMPRESSION_STRMAP_ZI_SYMBOL_PREFIX "strMap"
#define STRING_COMPRESSION_FIXED_STRRES_ZI_SYMBOL "strRes_Fixed"
#define STRING_COMPRESSION_FIXED_STRMAP_ZI_SYMBOL "strMap_Fixed"
#define STRING_COMPRESSION_DUP_STRRES_ZI_SYMBOL "strRes_Dup"


using namespace std;

class StrDecompressionBufferCreator;
class StrDecompressionBufferModel;
class StrMemBuffer;

class StrMemBuffer{
private:
    string symbolName;
    long size;
    string typeName;
public:
    StrMemBuffer(const char * symbolName, const char* typeName,int size);
    string& getSymbolName();
    long getSize();
    string& getTypeName();
};


class StrDecompressionBufferModel{
private:
    vector<StrMemBuffer*> strResMemBufs;
    vector<StrMemBuffer*> strMapMemBufs;
    StrMemBuffer* fixedStrResMemBuf;
    StrMemBuffer* fixedStrMapMemBuf;
    StrMemBuffer* dupStrResMemBuf;
public:
    StrDecompressionBufferModel();
    int addStrBufferByLang(StrMemBuffer * resBuf,StrMemBuffer *mapBuf);
    int setDupStrBuffer(StrMemBuffer * mapBuf);
    int setFixedStrBuffer(StrMemBuffer * resBuf,StrMemBuffer * mapBuf);
    StrMemBuffer * getStrResBuffer(unsigned int);
    StrMemBuffer * getStrMapBuffer(unsigned int);
    StrMemBuffer * getFixedStrResBuffer();
    StrMemBuffer * getFixedStrMapBuffer();
    StrMemBuffer * getDupStrResBuffer();
    int getTotalLanguages();
    ~StrDecompressionBufferModel();
};

class StrDecompressionBufferCreator{
private:
    string declartionStr;
    string definitionStr;
    StrDecompressionBufferModel model;
    string& getBufferEntryDeclaration(string& tempStr, StrMemBuffer * tempBuf);
    int singleStrResEnabled;

public:
    static char * STR_RES_TYPE;
    static char * STR_MAP_16_TYPE;
    static char * STR_MAP_32_TYPE;

    void setSingleStrResEnabled(int enabled);
    int setSingleStrResEnabled(void);

    StrDecompressionBufferCreator();
    int addStrBufferByLang(int resSize, int mapResSize, int is16Bit);
    int setDupStrBuffer(int resSize);
    int setFixedStrBuffer(int resSize, int mapResSize, int is16Bit);
    string * getDeclartionStatements();
    string * getDefinitionStatements(long reservedSize);
    string * getStrResBufferSymbol(int langIndex);
    string * getStrMapBufferSymbol(int langIndex);
    string * getFixedStrResBufferSymbol();
    string *getFixedStrMapBufferSymbol();
    string *getDupStrResBufferSymbol();

};

#endif //__STRING_CONPRESSION_BUFFER_H__
