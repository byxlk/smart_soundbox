/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#include "stdafx.h"

#include "OfflineResParamModel.h"
#include "OfflineResDAO.h"


//////////////////////////////////////////////////////////
// Public Static Variable
//////////////////////////////////////////////////////////

const int ResParamModel::REDUNDANT_ALLOWDED_ENABLE = 1;
const int ResParamModel::REDUNDANT_ALLOWDED_DISABLE = 0;
    

//////////////////////////////////////////////////////////
// Member Function
//////////////////////////////////////////////////////////
string * ResParamModel::getRepositoryFileName(){
    return this->repositoryFileName;
}

void ResParamModel::setRepositoryFileName(char * repository){
    if( repository!=NULL ){
        *this->repositoryFileName = repository;
    }
}


ResPopParam * ResParamModel::getResParamByEnumId(int resEnumId){
    if(this->idValueParamsMap!=NULL){
        map<int, ResPopParam *> ::iterator iterator;
        iterator = idValueParamsMap->find(resEnumId);
        if(iterator != idValueParamsMap->end()){
            return iterator->second;
        }else{
            return NULL;
        }
    }else{
        return NULL;
    }
}

ResPopParam * ResParamModel::getResParamByEnumIdName(string * resEnumName){
    if(this->idNameParamsMap!=NULL){
        map<string, ResPopParam *> ::iterator iterator;
        iterator = idNameParamsMap->find(*resEnumName);

        if(iterator != idNameParamsMap->end()){
            return iterator->second;
        }else{
            return NULL;
        }
    }else{
        return NULL;
    }
}

// The primary index is EnumId
void ResParamModel::addResParam(ResPopParam * resPopParam){
    if(resPopParam!=NULL){
        int enumId = resPopParam->getIdEnumValue();
        string * idName = resPopParam->getIdEnumString();
        string tmpStr;

        ResPopParam *temp = NULL;
        if(enumId == ResPopParam::ID_ENUM_VALUD_NOT_EXIST){
            resPopParam->toString(&tmpStr);
            cout<<"[WARNNING] Res ID can't be null, DUMP:\n\t"<<tmpStr<<endl;
            return;
        }
        // Check if the item is exist in map
        temp = this->getResParamByEnumId(enumId);
        if(temp == NULL && this->idValueParamsMap!= NULL ){
            if(this->idValueParamsMap!= NULL){
                (*this->idValueParamsMap)[enumId] = resPopParam;
            }else{
                cout<<"[WARNNING] idValueParamsMap NULL, ID = "<<resPopParam->getIdEnumValue()<<endl;
                return;
            }

            if( idName!= NULL && this->idNameParamsMap!=NULL){
                (*this->idNameParamsMap)[*idName] = resPopParam;
                this->orderedParams->push_back(resPopParam);
            }else{
                cout<<"[WARNNING] RES ID String can't be NULL, ID = "<<resPopParam->getIdEnumValue()<<endl;
                return;
            }

        }else{
            // ITEM is alreay populated
            // Add the item to redundantParams vector
            this->redundantParams->push_back(resPopParam);
            
            // Add to ordered population list only when redundantAllowed is set
            if(this->redundantAllowed && this->orderedParams!=NULL){
                this->orderedParams->push_back(resPopParam);
            }
        }
    }
}

vector<ResPopParam *> * ResParamModel::getAllResParams(){
    return this->orderedParams;
}


void ResParamModel::show(){
    map<int, ResPopParam *>::iterator iterator;
    cout<<"=================== ResParamModel Dump ========================="<<endl;
    // Iterate All items with idValueParamsMap
    for( iterator = this->idValueParamsMap->begin(); iterator != this->idValueParamsMap->end(); iterator++ ) {
        string tmp("");
        ResPopParam* param = iterator->second;
        param->toString(&tmp);
        cout << "[INFO] KEY: " << iterator->first << ", PARAM: (" <<tmp<< ")"<<endl;
    }


}

void ResParamModel::flush(ParamTextFileDAO * daoObj){
    if(this->orderedParams!=NULL && this->repositoryFileName!=NULL){
        daoObj->saveResPopParam(this->repositoryFileName,this->orderedParams);
		// Write out duplicated resource population
		if(this->redundantParams!=NULL){
			string * redundantDbName = new string(*(this->repositoryFileName));
			*redundantDbName = "dup_" + *redundantDbName;
			daoObj->saveResPopParam(redundantDbName,this->redundantParams);
			delete redundantDbName;
		}
    }else{
        cout<< "[ERROR]: ResParamModel::flush(), param can't be NULL"<<endl;
    }
}


void ResParamModel::loadFromRepository(ParamTextFileDAO * dao){
    if(this->repositoryFileName!=NULL && this->repositoryFileName->c_str()!=NULL){

    vector<ResPopParam*> * tmp = new vector<ResPopParam*>();
    // Read All Params
    dao->getResPopParams(this->repositoryFileName->c_str(), tmp);
    // Add params to Model
    for(unsigned int i=0;i< tmp->size();i++){
        if( (*tmp)[i] != NULL){
            this->addResParam((*tmp)[i]);
        }
    }
    delete tmp;
    }

}

void ResParamModel::setRedundantAllowed(int _redundantAllowed){
    this->redundantAllowed = _redundantAllowed;
}

int ResParamModel::getRedundantAllowed(){
    return this->redundantAllowed;
}

ResParamModel::ResParamModel(){
    this->redundantAllowed = ResParamModel::REDUNDANT_ALLOWDED_DISABLE;
    this->repositoryFileName = new string("default.text");
    this->idValueParamsMap = new map<int, ResPopParam *>();
    this->idNameParamsMap = new map<string, ResPopParam *>();
    this->redundantParams=new vector<ResPopParam *>();
    this->orderedParams = new vector<ResPopParam *>();
}

ResParamModel::~ResParamModel(){
    if(this->repositoryFileName!=NULL){
        delete this->repositoryFileName;
    }
    if(this->idValueParamsMap!=NULL){
        delete this->idValueParamsMap;
    }
    if(this->redundantParams!=NULL){
        delete this->redundantParams;
    }
    if(this->orderedParams!=NULL){
        delete this->orderedParams;
    }
}
