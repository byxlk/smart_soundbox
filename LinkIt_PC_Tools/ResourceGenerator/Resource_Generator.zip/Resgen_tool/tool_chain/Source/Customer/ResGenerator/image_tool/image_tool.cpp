#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <string.h>

FILE *image_res = NULL;

bool check_image_type(char *image_name){
	char temp_buffer[128];
	strcpy(temp_buffer, image_name);
	strlwr(temp_buffer);
	if (strstr(temp_buffer,".png") != NULL ||
		strstr(temp_buffer,".bmp") != NULL ||
		strstr(temp_buffer,".jpg") != NULL){
		return true;
	}
	return false;
}

void _replace(char *string, int length, char a, char b){
	int i = 0;
	for (i = 0; i < length; i++){
		if (string[i] == a){
			string[i] = b;
		}
	}
}

void find_file(char *path){
	struct _finddata_t files;
	char path_name[128]= {0};
	int file_handle;
	int i = 0;
	strcpy(path_name, path);
	strcat(path_name,"*.*");
	file_handle = _findfirst(path_name,&files);
	if (file_handle == -1){
		return;
	}
	do{
		if (strcmp(files.name,".") != 0 && strcmp(files.name,"..") != 0){
			if (files.attrib & _A_SUBDIR){
				strcpy(path_name, path);
				strcat(path_name, files.name);
				strcat(path_name, "\\");
				find_file(path_name);
			}
			else{
				if (check_image_type(files.name)){
					char image_name[128];
					char image_id[128];
					char image_info[256] = "    <IMAGE id=\"IMAGE_ID_";
					strcpy(image_name, path + 35);
					if (strlen(image_name) != 0){
						strcat(image_name,"\\");
					}
					strcat(image_name,files.name);
					strcpy(image_id, files.name);
					_replace(image_id, strlen(image_id), '.', '_');
					strupr(image_id);
					strcat(image_info,image_id);
					strcat(image_info,"\">CUST_IMG_PATH\"\\\\\\\\");
					strcat(image_info,image_name);
					strcat(image_info,"\"</IMAGE>\n");
					fprintf(image_res,"%s", image_info);
				}
			}
		}
	}while(0 == _findnext(file_handle,&files));
	_findclose(file_handle);
}

int main(int argc, char* argv[])
{
	char *image_path = "..\\..\\..\\..\\custom_resource\\images\\";
	printf("Auto add all image files in the folder \".\\custom_resource\\images\\\"\n");
	image_res = fopen("..\\..\\..\\..\\custom_resource\\custom.res","w+");
	if (image_res == NULL){
		return 0;
	}
	fputs("#include \"custresdef.h\"\n", image_res);
    fputs("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n", image_res);
    fputs("<APP id=\"CUSTOM\">\n\n", image_res);
    fputs("    <!-----------------------------------------------------Image Resource Area------------------------------------------------------>\n", image_res);
    fputs("    //CUST_IMG_PATH = \".\\custom_resource\\images\\\"\n", image_res);
    find_file(image_path);
    fputs("\n</APP>", image_res);
	fclose(image_res);
	//system("pause");
	return 0;
}