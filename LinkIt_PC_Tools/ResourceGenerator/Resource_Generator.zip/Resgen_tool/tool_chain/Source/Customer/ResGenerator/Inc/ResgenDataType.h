/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */

#ifndef __RESGEN_DATATYPE_H__
#define __RESGEN_DATATYPE_H__

#include <basetsd.h> // for __int64
#include <stdbool.h>

typedef enum {
    MMI_FALSE   = 0,
    MMI_TRUE    = 1
} MMI_BOOL;
typedef char                int8_t;
typedef unsigned char       uint8_t;
typedef unsigned short      uint16_t;
typedef unsigned int        uint32_t;
	
typedef char                S8;
typedef char                *PS8;
typedef unsigned char       U8;
typedef unsigned char       *PU8;

typedef unsigned short      pBOOL;
typedef int BOOL;

#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE 1
#endif

typedef short int           S16;
typedef short int           *PS16;
typedef unsigned short int  U16;
typedef unsigned short int  *PU16;

typedef int                 S32;
typedef int                 *PS32;
typedef unsigned int        U32;
typedef unsigned int        *PU32;

typedef float               FLOAT;

typedef unsigned __int64    U64;
typedef __int64             S64;
typedef void (*FuncPtrShort) (U16);

#ifndef _WCHAR_T_DEFINED
#define _WCHAR_T_DEFINED
#ifndef _WCHAR_T_
#define _WCHAR_T_
#undef __need_wchar_t
#ifndef __cplusplus
typedef unsigned short wchar_t;
#endif
#endif
#endif

typedef wchar_t WCHAR;

#ifndef NULL
#define NULL               0
#endif

#define MMI_EVT_PARAM_HEADER    \
    U16 evt_id;                 \
    U16 size;                   \
    void *user_data;


#define mmi_id              MMI_ID
#define mmi_img_id          MMI_IMG_ID
#define mmi_str_id          MMI_STR_ID
#define mmi_menu_id         MMI_MENU_ID
#define mmi_timer_id        MMI_TIMER_ID
#define mmi_event_id        MMI_EVENT_ID
#define mmi_ret             MMI_RET

typedef unsigned short      MMI_ID_TYPE;
typedef U16                 MMI_ID;         /* app id, group id, screen id */
typedef U16                 MMI_IMG_ID;     /* image or icon */
typedef U16                 MMI_STR_ID;     /* string */
typedef U16                 MMI_MENU_ID;    /* menu item id, hilite id, hint id */
typedef U16                 MMI_TIMER_ID;   /* timer */
typedef U16                 MMI_EVENT_ID;

typedef S32                 mmi_ret;

typedef enum {
    RES_IMAGE,
    RES_MEDIA,
    RES_AUDIO,
    RES_JAVA_GAME,
    RES_FONT,
    RES_BINARY
} RESOURCE_TYPE_LIST;

typedef enum _binary_type_enum
{
    BINARY_TYPE_INVALID,
    BINARY_TYPE_VENUS_XML,
    BINARY_TYPE_TOTAL
} binary_type_enum;

#endif // __RESGEN_DATATYPE_H__
