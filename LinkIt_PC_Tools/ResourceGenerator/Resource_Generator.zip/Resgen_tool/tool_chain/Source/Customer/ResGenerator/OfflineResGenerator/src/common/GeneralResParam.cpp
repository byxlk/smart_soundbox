/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#include "stdafx.h"

#include "OfflineResParam.h"
#include "OfflineResHelper.h"
//////////////////////////////////////////////////////
// Implementation of ResPopParam
/////////////////////////////////////////////////////

const unsigned int ResPopParam::ID_ENUM_VALUD_NOT_EXIST = 0xFFFFFFFF;

// Attribute Getters
unsigned int ResPopParam::getIdEnumValue(){
    return this->idEnumValue;
}
string * ResPopParam::getIdEnumString(){
    return this->idEnumString;
}
string * ResPopParam::getResFilePath(){
    return this->resFilePath;
}

string * ResPopParam::getDescription(){
    return this->description;
}

string * ResPopParam::getAppId(){
    return this->appId;
}

int ResPopParam::isNoCompiling(){
    return this->noCompiling;
}

// Attribute Setters

void ResPopParam::setIdEnumValue(int _idEnumString){
    this->idEnumValue = _idEnumString;
}
void ResPopParam::setIdEnumString(string *idEnumString){
    *(this->idEnumString) = *idEnumString;// Copy the enum String
    DAOHelper::StringTrim(*(this->idEnumString));
}

void ResPopParam::setIdEnumString(char *idEnumString){
    *(this->idEnumString) = idEnumString;// Copy the enum String
    DAOHelper::StringTrim(*(this->idEnumString));
}

void ResPopParam::setResFilePath(string * _resFilePath){
    *(this->resFilePath) = *_resFilePath;// Copy the enum String
}

void ResPopParam::setResFilePath(char * _resFilePath){
    *(this->resFilePath) = _resFilePath;// Copy the enum String
}

void ResPopParam::setDescription(char * _description){
    *(this->description) = _description;// Copy the enum String
}

void ResPopParam::setDescription(string * _description){
    if(_description!=NULL){
        *(this->description) = * _description;// Copy the enum String
    }
}


void ResPopParam::setAppId(string * appId){
    if(appId!=NULL){
        *(this->appId) = * appId;// Copy the enum String
    }
}
void ResPopParam::setAppId(char * appId){
    *(this->appId) = appId;// Copy the enum String
}


void ResPopParam::setNoCompiling(int _noCompiling){
    this->noCompiling = _noCompiling;
}

void ResPopParam::init(){
    this->idEnumValue = ResPopParam::ID_ENUM_VALUD_NOT_EXIST;
    this->idEnumString = new string();
    this->description = new string();
    this->resFilePath = new string();
    this->noCompiling = 1;
    this->appId = new string("APP name unknown");
}
