/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#include "stdafx.h"
#include <iostream>  
#include <fstream>  
#include <sstream>  
#include "OfflineResHelper.h"

using namespace std;  

const string DAOHelper::newLineToBeChecked = "\n";
const string DAOHelper::newLinePattern = "\\n";
const string DAOHelper::SLASH_ORIGINAL= "\\";
const string DAOHelper::SLASH_PATTERN = "\\\\";

const string DAOHelper::xmlSlash="\\\\\\\\";
const string DAOHelper::imagePathSlash="\\\\";
const string DAOHelper::xmlSlash_5="\\\\\\\\\\";
const string DAOHelper::xmlSlash_3="\\\\\\";

const  string DAOHelper::XML_QUOTE="\"";
const  string DAOHelper::IMAGE_PATH_QUOTE="";

//const string SPACES =" \t\r\n";

string& DAOHelper::StringTrim(string &st,const string & t){
    string d(st);
    st = rTrim(lTrim(d, t), t);
    return st;

}

string&  DAOHelper::lTrim(string &st,const string & t )  
{   
    string d(st);
    st = d.erase(0, st.find_first_not_of (t));
    return st;
}   

string& DAOHelper::rTrim(string &st,const string & t) 
{   
    string d (st);
    string::size_type i(d.find_last_not_of (t));
    if (i == string::npos){
        st ="";
    }else{
        st = d.erase(d.find_last_not_of (t) + 1) ;
    }
    return st;
}   



void DAOHelper::stringEscapeNewLine(string * dest){

    DAOHelper::stringReplaceAll(dest, &newLineToBeChecked, &newLinePattern);

}

void DAOHelper::stringRecoverEscapedNewLine(string * dest){

    DAOHelper::stringReplaceAll(dest, &newLinePattern,&newLineToBeChecked);

}

void DAOHelper::stringEscapeSlash(string * dest){

    DAOHelper::stringReplaceAll(dest, &SLASH_ORIGINAL, &SLASH_PATTERN);

}

void DAOHelper::stringRecoverEscapedSlash(string * dest){

    DAOHelper::stringReplaceAll(dest, &SLASH_PATTERN,&SLASH_ORIGINAL);

}


void DAOHelper::stringReplaceAll(string * dest, const string * toBeReplace, const string* newPart){
    string::size_type p1 = 0;// search start
    string::size_type p2 = 0;// copy start
    p2 = dest->find(*toBeReplace,p1);

    while( p1 >= 0 && p2>= 0 && p2!= string::npos){

        dest->replace(p2, toBeReplace->length(), *newPart);
        p1 = p2 + newPart->length();

        if(p1 >= dest->length() ){
            break;
        }

        p2 = dest->find(*toBeReplace,p1);
    }

}

void DAOHelper::stringTokenize(const string& str,
                               vector<string>& tokens,
                               const string& delimiters )
{
    string::size_type p1 = 0;// copy start
    string::size_type p2 = str.find_first_of(delimiters, 0); // next copy start
    string::size_type p3 = string::npos;

    while( p1>=0 &&p2 < str.length() && p2!= string::npos){
        string s = str.substr(p1, p2 - p1);
        tokens.push_back(s);
        p3 = str.find_first_of(delimiters, p2+1);
        p1 = p2+1;
        p2 = p3;

    }
}

void DAOHelper::stringTokenizeWithLast(const string& str,
                                       vector<string>& tokens,
                                       const string& delimiters )
{
    string::size_type p1 = 0;// copy start
    string::size_type p2 = str.find_first_of(delimiters, 0); // next copy start
    string::size_type p3 = string::npos;

    while( p1>=0 &&p2 < str.length() && p2!= string::npos){
        string s = str.substr(p1, p2 - p1);
        tokens.push_back(s);
        p3 = str.find_first_of(delimiters, p2+1);
        p1 = p2+1;
        p2 = p3;

    }
    string::size_type last_indx  = str.size() - 1;
    if(p1 <= last_indx){
        string last = str.substr(p1, (last_indx - p1 +1) );
        tokens.push_back(last);
    }
}

void DAOHelper::convertToResFileName(char * resFileName, char * path, char * immediateFileName, int sizeLimit){
    string inputStr = "";
    string resturnStr = "";
    
    if(path != NULL){
        inputStr = path;
    }
    if(immediateFileName!=NULL){
        inputStr += immediateFileName;
    }

    string::size_type end_pos     = inputStr.find_last_of(".");

    if(end_pos > 0 && end_pos!= string::npos){
        resturnStr = inputStr.substr(0, end_pos);
    }else{
        resturnStr = inputStr;
    }
    resturnStr +=".res";
    strncpy(resFileName, resturnStr.c_str(),sizeLimit);
}

void DAOHelper::pathCorrect(string * dest){
    const string delimiters("\\");
    string::size_type start_pos     = dest->find_first_of(delimiters, 0);
    string::size_type last_pos      = dest->find_first_not_of(delimiters, start_pos);

    while(start_pos != string::npos ){
        string::size_type len = string::npos;
        if(last_pos!=string::npos ){
            len = last_pos - start_pos;
        }else{
            len = dest->length() - start_pos;

        }

        if(len %2 !=0){
            // Correct it!!
            dest->erase(start_pos,1);
            last_pos = last_pos-1;
        }        
        start_pos     = dest->find_first_of(delimiters, last_pos);
        last_pos      = dest->find_first_not_of(delimiters, start_pos);
    }
}
