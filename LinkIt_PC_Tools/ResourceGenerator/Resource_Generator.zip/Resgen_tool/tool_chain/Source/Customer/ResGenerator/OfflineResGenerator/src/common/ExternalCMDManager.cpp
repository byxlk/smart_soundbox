/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#include <cstdlib>
#include <iostream>
#include "ResgenLogCAPI.h"

extern "C"{
#include "ExternalCMDManagerCAPI.h"
}


using namespace std;

// External Interface for C sources


#define EXTCMD_TAG        "EXTERNALCMDMANAGER"

#define EXTCMD_LOG_D(format, args...) RES_LOG_D((EXTCMD_TAG), (format) , ##args)
#define EXTCMD_LOG_V(format, args...) RES_LOG_V((EXTCMD_TAG), (format) , ##args)
#define EXTCMD_LOG_W(format, args...) RES_LOG_W((EXTCMD_TAG), (format) , ##args)
#define EXTCMD_LOG_E(format, args...) RES_LOG_E((EXTCMD_TAG), (format) , ##args)


////////////////////////////////////////////////////////
// External Command Manager
////////////////////////////////////////////////////////


class ExternalCMDManager{
public:
    static int execute(string command_str);
    static int execute(const char * command_str);
};

int ExternalCMDManager::execute(string command_str){
    return ExternalCMDManager::execute(command_str.c_str());
}

int ExternalCMDManager::execute(const char * command_str){
    int sys_result = 0;
    try{
        EXTCMD_LOG_V("Start external script:\t%s",command_str);
        EXTCMD_LOG_V("---------------- The following log is generated from %s:",command_str);
        sys_result = std::system(command_str);
        EXTCMD_LOG_V("---------------- The above log is generated from %s:",command_str);
        EXTCMD_LOG_V("Finish external script:\t%s",command_str);
    }catch(...){
        EXTCMD_LOG_E("Received unknown excetion in ExternalCMDManager::execut");
    }
    return sys_result;
}

////////////////////////////////////////////////////////
// C API interface
////////////////////////////////////////////////////////

// This is a temp implemenation of C system command wrapper API
int execute_ext_command(char * command_str)
{
    return ExternalCMDManager::execute(command_str);
}
