/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#ifndef RESXML_AUDIO_H
#define RESXML_AUDIO_H


#include "MMIDataType.h"

#if defined(__MMI_FRM_INPUT_EVT__)
#define MMI_RP_MGR_ATTR_AUD_PATH "path"
#endif/*#if defined(__MMI_FRM_INPUT_EVT__)*/

typedef enum
{
    MMI_RP_AUD_FORCE_TYPE_NONE,
    MMI_RP_AUD_FORCE_TYPE_AUTO,
    MMI_RP_AUD_FORCE_TYPE_MIDI,
    MMI_RP_AUD_FORCE_TYPE_TOTAL
}mmi_rp_aud_force_type_enum;

typedef struct
{
    U8 *aud_id_str;
    U8 *aud_desc_str;
    U8 *format;
    U8 *file_path;
#if defined(__MMI_FRM_INPUT_EVT__)
    U8 *aud_path;//record aud real path
#endif/*#if defined(__MMI_FRM_INPUT_EVT__)*/    
    MMI_BOOL is_theme;
    MMI_BOOL filter;                         /* filter-out -> MMI_FALSE, filter-in -> MMI_TRUE */
    mmi_rp_aud_force_type_enum force_type;   /* "AUTO_ADO_TYPE", "FORCE_ADO_MIDI" */
    mmi_rp_flag_bin_enum flag;               /* Multi/single bin */
}mmi_rp_aud_id_struct;

typedef struct
{
    U32 total_count;
    mmi_rp_aud_id_struct *audios;
}mmi_rp_aud_data_struct;

typedef struct
{
    mmi_rp_aud_data_struct *app_aud_data;
    mmi_rp_hash_struct *id_hash;
    mmi_rp_hash_struct *file_path_hash;
}mmi_rp_aud_cntx_struct;

extern void mmi_rp_aud_init(void);
extern void mmi_rp_aud_deinit(void);
extern void mmi_rp_aud_set_app_range(void);

extern int mmi_rp_aud_start_handler(void *data, const kal_char *el, const kal_char **attr);
extern int mmi_rp_aud_end_handler(void *data, const kal_char *el);
extern int mmi_rp_aud_data_handler(void *resv, const kal_char *el, const kal_char *data, kal_int32 len);

extern void mmi_rp_aud_filter(void);

extern void mmi_rp_aud_output_phase1(void);
extern void mmi_rp_aud_output_phase2(void);

#endif /* RESXML_AUDIO_H */
