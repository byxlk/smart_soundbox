/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */

#include "stdafx.h"

#include "OfflineResParam.h"
#include "OfflineResDAO.h"


// Member function implementation

void AudioResParam::toString(string * result){
    stringstream oss;
    oss << this->idEnumValue<<'\t';
    oss << *(this->idEnumString)<<'\t';
    oss << *(this->description)<<'\t';
    oss << *(this->resFilePath)<<'\t';
    oss << this->noCompiling<<'\t';
    oss << this->isMultipleBin<<'\t';
    oss << this->forceType<<'\t';
    oss << *this->audioFilePath<<'\t';
    oss<< *(this->appId)<<'\t';

    *result =  oss.str();
}

AudioResParam::AudioResParam(){
    this->init();
}


// Implementation of AudioResParam
AudioResParam::AudioResParam(int _idEnumValue, string * _idEnumString, string * _resFilePath,string * _description,int _noCompiling, int _isMultipleBin, int _forceType, string * _audioFilePath){
    this->init();
    this->setIdEnumValue(_idEnumValue);
    this->setIdEnumString(_idEnumString);
    this->setDescription(_description);
    this->setResFilePath(_resFilePath);
    this->setNoCompiling(_noCompiling);    
    this->setIsMultipleBin(_isMultipleBin);
    this->setForceType(_forceType);
    this->setAudioFilePath(_audioFilePath);
}

AudioResParam::AudioResParam(int _idEnumValue, char * _idEnumString, char * _resFilePath, char * _description,int _noCompiling, int _isMultipleBin, int _forceType, char * _audioFilePath){
    init();
    this->setIdEnumValue(_idEnumValue);
    this->setIdEnumString(_idEnumString);
    this->setDescription(_description);
    this->setResFilePath(_resFilePath);
    this->setNoCompiling(_noCompiling);
    this->setIsMultipleBin(_isMultipleBin);
    this->setForceType(_forceType);
    this->setAudioFilePath(_audioFilePath);
}
// Implementation of AudioResParam
AudioResParam::AudioResParam(int _idEnumValue, string * _idEnumString, string * _resFilePath,string * _description,int _noCompiling, int _isMultipleBin, int _forceType, string * _audioFilePath, int _xmlSource){
    this->init();
    this->setIdEnumValue(_idEnumValue);
    this->setIdEnumString(_idEnumString);
    this->setDescription(_description);
    this->setResFilePath(_resFilePath);
    this->setNoCompiling(_noCompiling);    
    this->setIsMultipleBin(_isMultipleBin);
    this->setForceType(_forceType);
    this->setAudioFilePath(_audioFilePath);
    if(_xmlSource){
        DAOHelper::stringReplaceAll(this->audioFilePath,&DAOHelper::xmlSlash_5,&DAOHelper::imagePathSlash);
        DAOHelper::stringReplaceAll(this->audioFilePath,&DAOHelper::xmlSlash,&DAOHelper::imagePathSlash);
        DAOHelper::stringReplaceAll(this->audioFilePath,&DAOHelper::xmlSlash_3,&DAOHelper::SLASH_ORIGINAL);
        DAOHelper::stringReplaceAll(this->audioFilePath,&DAOHelper::XML_QUOTE,&DAOHelper::IMAGE_PATH_QUOTE);
    }

}

AudioResParam::AudioResParam(int _idEnumValue, char * _idEnumString, char * _resFilePath, char * _description,int _noCompiling, int _isMultipleBin, int _forceType, char * _audioFilePath,int _xmlSource){
    init();
    this->setIdEnumValue(_idEnumValue);
    this->setIdEnumString(_idEnumString);
    this->setDescription(_description);
    this->setResFilePath(_resFilePath);
    this->setNoCompiling(_noCompiling);
    this->setIsMultipleBin(_isMultipleBin);
    this->setForceType(_forceType);
    this->setAudioFilePath(_audioFilePath);
    if(_xmlSource){
        DAOHelper::stringReplaceAll(this->audioFilePath,&DAOHelper::xmlSlash_5,&DAOHelper::imagePathSlash);
        DAOHelper::stringReplaceAll(this->audioFilePath,&DAOHelper::xmlSlash,&DAOHelper::imagePathSlash);
        DAOHelper::stringReplaceAll(this->audioFilePath,&DAOHelper::xmlSlash_3,&DAOHelper::SLASH_ORIGINAL);
        DAOHelper::stringReplaceAll(this->audioFilePath,&DAOHelper::XML_QUOTE,&DAOHelper::IMAGE_PATH_QUOTE);
    }

}


AudioResParam::~AudioResParam(){
    delete this->idEnumString;
    delete this->description;
    delete this->resFilePath;
    delete this->audioFilePath;
    delete this->appId;
}



void AudioResParam::init(){
    ResPopParam::init();
    this->setNoCompiling(1); // Default audio resource is not need compilation
    this->audioFilePath = new string("");

}



// Attribute Getter/Setter Functions:
// Do error check in Getter and Setter functions to
// ensure there is no unexpect attribute value to be set or
// get.

int AudioResParam::getIsMultipleBin(){
    return this->isMultipleBin;
}

int AudioResParam::getForceType(){
    return this->forceType;
}

string * AudioResParam::getAudioFilePath(){
    return this->audioFilePath;
}


void AudioResParam::setIsMultipleBin(int _isMultipleBin){
    this->isMultipleBin = _isMultipleBin;
}


void AudioResParam::setForceType(int _forceType){
    this->forceType=_forceType;
}
void AudioResParam::setAudioFilePath(string * _audioFilePath){
    this->audioFilePath->assign( *(_audioFilePath));

}

void AudioResParam::setAudioFilePath(char * _audioFilePath){
    if(_audioFilePath == NULL){
        this->audioFilePath->assign("");
    }
    else{
        this->audioFilePath->assign(_audioFilePath);
    }

}



void AudioParamTextFileDAO::toSerializedString(ResPopParam * _param, string * strLine){
    string temp("");
    _param->toString(&temp);
    *strLine = temp;
}


ResPopParam * AudioParamTextFileDAO::parseResParam( string * strLine){

    AudioResParam * param= NULL;
    vector<string> tokens;
    unsigned int enumId = 0;
    int lIsNoCompiled = -1;
    int lIsMultipleBin = 0;
    int lForceType = -1;

    if(strLine == NULL || strLine->length()<=0){
        return NULL;
    }

    param = new AudioResParam();
    DAOHelper::stringTokenize(*strLine, tokens);

    std::stringstream strStream(tokens[0]);
    strStream>>enumId;
    // Parser isNoCompiled
    strStream.clear();
    strStream.str("");
    strStream<<tokens[4];
    strStream>>lIsNoCompiled;
    // Parse isMultipleBin
    strStream.clear();
    strStream.str("");
    strStream<<tokens[5];
    strStream>>lIsMultipleBin;
    // Parser forceType
    strStream.clear();
    strStream.str("");
    strStream<<tokens[6];
    strStream>>lForceType;

    param->setIdEnumValue(enumId);
    param->setIdEnumString(&tokens[1]);
    param->setAppId(&tokens[8]);
    param->setDescription(&tokens[2]);
    param->setResFilePath(&tokens[3]);
    param->setNoCompiling(lIsNoCompiled);
    param->setIsMultipleBin(lIsMultipleBin);
    param->setForceType(lForceType);
    param->setAudioFilePath(&tokens[7]);
    return param;

}
