/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */

#include "stdafx.h"
#include "ImageGroupCreator.h"

/*
Reference: 
class ImageSymbol{
private:
string sourceFile;
char * data;
int size;
int * noCompression;
public:
ImageSymbol(char * sourceFile, char* data, int noCompression);
void toMetaString(string *buffer);
string& getSourceFile();
char* getData();
int getSize();
int getNoCompression();
void setNoCompression(int noCompression);
};
*/
string & ImageSymbol::getSourceFile(){
	return this->sourceFile;
}

int ImageSymbol::getSize(){
	return this->size;
}

int ImageSymbol::getNoCompression(){
	return this->noCompression;
}

void ImageSymbol::setNoCompression(int noCompression){
	this->noCompression = noCompression;
}

ImageSymbol::ImageSymbol(const char * sourceFile, char* data, int size,int noCompression){
	this->sourceFile = sourceFile;
	this->data = data;
	this->size = size;
	this->noCompression = noCompression;
}

// META section format:
// ########################################################
// FILE: [FILE NAME]
// NO_COMPRESSION: [Y/N]
// DATA: 
void ImageSymbol::toMetaString(string *buffer){
	if(this->size <= 0 && buffer !=NULL){
		*buffer = "";
		return;
	}

	stringstream oss;
	oss<<"########################################################"<<endl;
	oss<<"FILE:\t"<<this->sourceFile<<endl;
	oss<<"NO_COMPRESSION:\t";
	if(this->noCompression > 0){
		oss<<"Y"<<endl;
	}else{
		oss<<"N"<<endl;
	}
	oss<<"DATA:"<<endl;
	// ensure the string has the end pattern
	char * safeData = new char[this->size+1];
	memcpy(safeData, data, size);
	safeData[size] = '\0';

	oss<<safeData<<endl;
	if(buffer !=NULL){
		*buffer = oss.str();
	}
	delete [] safeData;
	return;
}

/*
class ImageGroupContentMetaCreator{
private:
map<string,ImageSymbol *> symbolMap;
vector<ImageSymbol*> orderedSymbolList;
public:
// Release and Clear images added to the creator
int reset();
// Added a image data
int addImage(char * sourceFile, char* data, int noCompression);
// Create the meta file for the image symbols
int generateMetaFile(char * fileName);
};
*/

ImageGroupContentMetaCreator::ImageGroupContentMetaCreator(){
	// Do nothing now
}

int ImageGroupContentMetaCreator::addImage(const char * sourceFile, char* data, int size, int noCompression){
	if(sourceFile == NULL || data == NULL || size <=0){
		return 0;
	}
	//check if the symbol already added
	if(this->symbolMap[sourceFile] == NULL){
		this->symbolMap[sourceFile]  = new ImageSymbol(sourceFile,data,size,noCompression);
		orderedSymbolList.push_back(this->symbolMap[sourceFile]);
	}else{
		if(noCompression == 1){
			this->symbolMap[sourceFile]->setNoCompression(1);
		}
	}
	return 1;
}

ImageGroupContentMetaCreator::~ImageGroupContentMetaCreator(){
	this->reset();
}

int ImageGroupContentMetaCreator::reset(){
	for(unsigned int i=0;i<orderedSymbolList.size();i++){
		if(orderedSymbolList[i]!=NULL){
			delete orderedSymbolList[i];
			orderedSymbolList[i] = NULL;
		}
	}
	orderedSymbolList.clear();
	symbolMap.clear();
	return 1;
}

int ImageGroupContentMetaCreator::generateMetaFile(const char * fileName){
	unsigned int i = 0;

	if( fileName ==NULL){
		return 0;
	}

	ofstream outfile;
	outfile.open(fileName);
	string tmp("");

	for(i=0;i<orderedSymbolList.size();i++){
		if(orderedSymbolList[i]!=NULL){
			orderedSymbolList[i]->toMetaString(&tmp);
			outfile<<tmp<<'\n';
		}

	}
	outfile.close();
	return 1;
}

/*
class ImageGroupMappingMetaCreator{
private:
    vector<string*> orderedSymbolList;
public:
	int reset();
	int addImage(const char * symbolName);
	int generateMetaFile(const char * fileName);
	ImageGroupMappingMetaCreator();
	~ImageGroupMappingMetaCreator();
};
*/
ImageGroupMappingMetaCreator::ImageGroupMappingMetaCreator(){
	//Do nothing now
}

int ImageGroupMappingMetaCreator::addImage(const char * image){
	string * str = new string(image);
	orderedSymbolList.push_back(str);
	return 1;
}

int ImageGroupMappingMetaCreator::reset(){
	for(unsigned int i=0;i<orderedSymbolList.size();i++){
		if(orderedSymbolList[i]!=NULL){
			delete orderedSymbolList[i];
			orderedSymbolList[i] = NULL;
		}
	}
	orderedSymbolList.clear();
	return 1;
}

int ImageGroupMappingMetaCreator::generateMetaFile(const char * fileName){
		unsigned int i = 0;

	if( fileName ==NULL){
		return 0;
	}

	ofstream outfile;
	outfile.open(fileName);
	string tmp("");

	for(i=0;i<orderedSymbolList.size();i++){
		if(orderedSymbolList[i]!=NULL){
			outfile<<*(orderedSymbolList[i])<<'\n';
		}

	}
	outfile.close();
	return 1;
}
ImageGroupMappingMetaCreator::~ImageGroupMappingMetaCreator(){
	this->reset();
}