/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#ifndef _OFFLINERESPARAM_H
#define _OFFLINERESPARAM_H

#include <iostream>  
#include <fstream>  
#include <sstream>  
#include <string>
#include <map>
#include <vector>

using namespace std;


class ResPopParam{
protected:
    unsigned int idEnumValue;
    string * appId;
    string * idEnumString;
    string * resFilePath;
    string * description;
    int noCompiling;
    virtual void init();
public:
    const static unsigned int ID_ENUM_VALUD_NOT_EXIST;
    unsigned int getIdEnumValue();
    string * getIdEnumString();
    string * getResFilePath();
    string * getDescription();
    string * getAppId();
    int isNoCompiling();

    void setIdEnumValue(int idEnumValue);
    void setIdEnumString(string *idEnumString);
    void setIdEnumString(char *idEnumString);

    void setResFilePath(string *resFilePath);
    void setResFilePath(char *resFilePath);

    void setDescription(string * description);
    void setDescription(char * description);

    void setAppId(string * appId);
    void setAppId(char* appId);

    void setNoCompiling(int noCompiling);


    virtual void toString(string * result) =0;
};

/**
* @brief StringResParam carries string poplulation
* parameters. It is also the traffic object between
* data access layer to Model/Control/View Layer
* 
*/
class StringResParam: public ResPopParam{
private:
    string * defaultString;
    virtual void init();
public:
    virtual void toString(string * result);
    StringResParam();
    StringResParam(int _idEnumValue, string * _idEnumString, string* _resFilePath,string *_description, int _noCompiling, string* _defaultString);
    StringResParam(int _idEnumValue, string * _idEnumString, string* _resFilePath,string *_description, int _noCompiling);
    StringResParam(int _idEnumValue, char * _idEnumString, char * _resFilePath,char * _description, int _noCompiling);
    StringResParam(int _idEnumValue, char * _idEnumString, char * _resFilePath,char * _description, int _noCompiling, char* _defaultString);
    ~StringResParam();

    string * getDefaultString();
    void setDefaultString(string * _defaultString);
    void setDefaultString(char * _defaultString);
};


/**
* @brief ImageResParam carries image poplulation
* parameters. It is also the traffic object between
* data access layer to Model/Control/View Layer
* 
*/

class ImageResParam: public ResPopParam{
private:
    string * imageFilePath;
    int isMultipleBin;
    int forceType;
    int isENFB;
    int quality;
	int isCompression;
	
    virtual void init();
public:
    static int QUALITY_HIGH;
    static int QUALITY_MEDIUM;
    static int QUALITY_LOW;

    virtual void toString(string * result);
    ImageResParam();
    ImageResParam(int _idEnumValue, string * _idEnumString, string* _resFilePath,string *_description, int _noCompiling, int _isMultipleBin, int _forceType, string * _imageFilePath, int _isENFB);
    ImageResParam(int _idEnumValue, char * _idEnumString, char * _resFilePath,char * _description, int _noCompiling, int _isMultipleBin, int _forceType,char * _imageFilePath, int _isENFB);
    ImageResParam(int _idEnumValue, char * _idEnumString, char * _resFilePath,char * _description, int _noCompiling, int _isMultipleBin, int _forceType,char * _imageFilePath, int _isENFB, int _xmlSource);
    ImageResParam(int _idEnumValue, string * _idEnumString, string* _resFilePath,string *_description, int _noCompiling, int _isMultipleBin, int _forceType, string * _imageFilePath, int _isENFB,int _xmlSource);

    ~ImageResParam();
    int getIsMultipleBin();
	int getIsCompression();
    int getForceType();
    string * getImageFilePath();
    int getIsENFB();

    void setIsMultipleBin(int _isMultipleBin);
	void setIsCompression(int isCompression);
    void setForceType(int _forceType);
    void setImageFilePath(string * _imageFilePath);
    void setImageFilePath(char * _imageFilePath);
    void setIsENFB(int isENFB);
    void setQuality(int quality);
    int getQuality();

};

/**
* @brief AudioResParam carries audio poplulation
* parameters. It is also the traffic object between
* data access layer to Model/Control/View Layer
* 
*/
class AudioResParam: public ResPopParam{
private:
    string * audioFilePath;
    int isMultipleBin;
    int forceType;
    void init();
public:
    virtual void toString(string * result);
    AudioResParam();
    AudioResParam(int _idEnumValue, string * _idEnumString, string* _resFilePath, string *_description, int _noCompiling, int _isMultipleBin, int _forceType, string * _audioFilePath);
    AudioResParam(int _idEnumValue, char * _idEnumString, char * _resFilePath,char * _description, int _noCompiling, int _isMultipleBin, int _forceType, char * _audioFilePath);
    AudioResParam(int _idEnumValue, string * _idEnumString, string* _resFilePath, string *_description, int _noCompiling, int _isMultipleBin, int _forceType, string * _audioFilePath, int xmlCorrect);
    AudioResParam(int _idEnumValue, char * _idEnumString, char * _resFilePath,char * _description, int _noCompiling, int _isMultipleBin, int _forceType, char * _audioFilePath,int xmlCorrect);

    ~AudioResParam();

    int getIsMultipleBin();
    int getForceType();
    string * getAudioFilePath();

    void setIsMultipleBin(int _isMultipleBin);
    void setForceType(int _forceType);
    void setAudioFilePath(string * _audioFilePath);
    void setAudioFilePath(char * _audioFilePath);

};


/**
* @brief BinaryResParam carries audio poplulation
* parameters. It is also the traffic object between
* data access layer to Model/Control/View Layer
* 
*/
class BinaryResParam: public ResPopParam{
private:
    string * binaryFilePath;
    int binaryType;
    void init();
public:
    virtual void toString(string * result);
    BinaryResParam();
    BinaryResParam(int _idEnumValue, string * _idEnumString, string* _resFilePath, string *_description, int _noCompiling, int _forceType, string * _audioFilePath);
    BinaryResParam(int _idEnumValue, char * _idEnumString, char * _resFilePath,char * _description, int _noCompiling, int _forceType, char * _audioFilePath);
    BinaryResParam(int _idEnumValue, string * _idEnumString, string* _resFilePath, string *_description, int _noCompiling, int _forceType, string * _audioFilePath, int isFromXML);
    BinaryResParam(int _idEnumValue, char * _idEnumString, char * _resFilePath,char * _description, int _noCompiling, int _forceType, char * _audioFilePath, int isFromXML);

    ~BinaryResParam();

    int getBinaryType();
    void setBinaryType(int _binaryType);

    string * getBinaryFilePath();

    void setBinaryFilePath(string * _binaryFilePath);
    void setBinaryFilePath(char * _binaryFilePath);

};
#endif //_OFFLINERESPARAM_H
