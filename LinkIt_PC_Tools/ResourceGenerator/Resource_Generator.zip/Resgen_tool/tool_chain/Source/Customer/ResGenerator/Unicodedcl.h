/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
/**
 * Copyright Notice
 * ?2002 - 2003, Pixtel Communications, Inc., 1489 43rd Ave. W.,
 * Vancouver, B.C. V6M 4K8 Canada. All Rights Reserved.
 *  (It is illegal to remove this copyright notice from this software or any
 *  portion of it)
 */

/************************************************************** 
 FILENAME   : Unicode.h 
 PURPOSE : Gives the current build settings. 
 REMARKS : Manish 
 AUTHOR     : Pixtel Engineers 
 DATE    : . 
 **************************************************************/

#ifndef _UNICODEDCL_H_
#define _UNICODEDCL_H_

#include "MMIDataType.h"


#if defined (__MMI_FRAMEWORK_BACKWARD_COMPATIBLE__) || defined (__MMI_FRAMEWORK_BACKWARD_COMPATIBLE_SPEC__)
/* only MMITask.c include this file to declare the global variables */

U8(*pfnUnicodeToEncodingScheme) (U16 Unicode, U8 *CharacterLength, U8 *CharBuffer);

U8(*pfnEncodingSchemeToUnicode) (PU16 pUnicode, PU8 arrOut);

S32(*pfnUnicodeStrlen) (const S8 *arrOut);

PS8(*pfnUnicodeStrcpy) (S8 *strDestination, const S8 *strSource);

PS8(*pfnUnicodeStrncpy) (S8 *strDestination, const S8 *strSource, U32 size);

S32(*pfnUnicodeStrcmp) (const S8 *string1, const S8 *string2);

S32(*pfnUnicodeStrncmp) (const S8 *string1, const S8 *string2, U32 size); 

PS8(*pfnUnicodeStrcat) (S8 *strDestination, const S8 *strSource);

PS8(*pfnUnicodeStrncat) (S8 *strDestination, const S8 *strSource, U32 size);

#endif /* __MMI_FRAMEWORK_BACKWARD_COMPATIBLE__ */



#endif /* _UNICODEDCL_H_ */ 

