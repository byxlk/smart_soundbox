/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */

#include "CustDataRes.h"
#include "CustDataProts.h"
#include "CustMenuRes.h"
#include "FontDCl.h"
#include "FontRes.h"
#include "GlobalMenuItems.h"



#define	MAX_TOTALSTRLEN_1	90000 
#define	MAX_STRINGID_1	MAX_STRING_MAP_SIZE


unsigned short  CurrMaxMenuItemIndex=1500;

unsigned short gdi_resource_current_max_image_id=1000;
unsigned short gdi_resource_current_max_search_image_id=150;
unsigned short  CurrMaxImageNum=600;

unsigned short CurrMaxImageIdEXT=1000;
unsigned short CurrMaxSearchImageIdEXT=150;
unsigned short  CurrMaxImageNumEXT=600;

unsigned short CurrMaxFontIdEXT = 1000;
unsigned short CurrMaxSearchFontIdEXT = 150;
unsigned short CurrMaxFontNumEXT = 600;

unsigned short CurrMaxAudioId=1000;
unsigned short CurrMaxSearchAudioId=150;
unsigned short  CurrMaxAudioNum=600;
unsigned short CurrMaxAudioIdEXT=1000;
unsigned short CurrMaxSearchAudioIdEXT=150;
unsigned short  CurrMaxAudioNumEXT=600;

/* 101806 E-NFB start */
// #ifdef __MMI_RESOURCE_ENFB_SUPPORT__
#if 0
unsigned short CurrMaxENFBAssociatedIDNum=0;
CUSTOM_ENFB_STR ENFBAssociatedIDList[MAX_ASSOCIATED_IDS];
ENFB_Font_Res_Info ENFBFontResInfo[MAX_LANGUAGES];
#endif
// #endif
/* 101806 E-NFB end */

/* dummy declaration for resource gen */

sLanguageDetails gLanguageArray[MAX_LANGUAGES];
U16 gMaxDeployedLangs = 3;

//gdi_resource_custom_image_t	nCustImageNames[MAX_IMAGE_NAMES_SIZE];
CustDataRes gdi_resource_custom_image_id_map[MAX_IMAGE_IDS_SIZE];
gdi_resource_custom_image_search_map_t gdi_resource_image_id_search_map[500];

// __CUSTPACK_MULTIBIN
CustDataRes ImageIdMapEXT[MAX_IMAGE_IDS_SIZE];
gdi_resource_custom_image_search_map_t ImageIdSearchMapEXT[500];

/* langpack for vector font */
CUSTOM_FONT_MAP FontIdMapEXT[MAX_FONT_IDS_SIZE];
CUSTOM_FONT_SEARCH_MAP FontIdSearchMapEXT[500];

/*
gdi_resource_custom_string_map_16_t	StrMap_1[MAX_STRINGID_1];
gdi_resource_custom_string_t	StrRes_1[MAX_TOTALSTRLEN_1];
gdi_resource_string_map_search_t	StrMapSearch[500];

gdi_resource_string_resource_list_t	gStringList[MAX_LANGUAGES]={
{(gdi_resource_custom_string_t*)StrRes_1,2688,(gdi_resource_custom_string_map_16_t*)StrMap_1,3625,(gdi_resource_string_map_search_t *)StrMapSearch,223}, 
};
*/


IMAGENAME_LIST	ImageNameList[MAX_IMAGE_NAMES_SIZE];

/* __CUSTPACK_MULTIBIN  */
IMAGENAME_LIST	ImageNameListEXT[MAX_IMAGE_NAMES_SIZE];//040805 CustPack: Calvin added

/* Langpack for Vecotr font */
FONTNAME_LIST FontNameListEXT[MAX_FONT_NAMES_SIZE];  

/*101205 audio resource Calvin Satrt */
CUSTOM_AUDIO_MAP AudioIdMap[MAX_AUDIO_IDS_SIZE];
CUSTOM_AUDIO_SEARCH_MAP AudioIdSearchMap[500];
CUSTOM_AUDIO_MAP AudioIdMapEXT[MAX_AUDIO_IDS_SIZE];
CUSTOM_AUDIO_SEARCH_MAP AudioIdSearchMapEXT[500];
AUDIONAME_LIST	AudioNameList[MAX_AUDIO_NAMES_SIZE];
AUDIONAME_LIST	AudioNameListEXT[MAX_AUDIO_NAMES_SIZE];//040805 CustPack: Calvin added
/*101205 audio resource Calvin End */

CUSTOM_MENU		nCustMenus[MAX_MENU_ITEMS];


/* Menuitem reduce memory, move registe hilite handlers to resgen */
RESGEN_MENU_HILITE_HANDLER		nMenuHiliteHandlers[MAX_MENU_ITEMS];
RESGEN_MENU_HINT_HANDLER		nMenuHintHandlers[MAX_MENU_ITEMS];

