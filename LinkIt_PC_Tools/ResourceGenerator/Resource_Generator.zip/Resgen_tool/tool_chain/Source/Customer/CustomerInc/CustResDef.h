/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#ifndef _CUST_RES_DEF_H
#define _CUST_RES_DEF_H

#include "MMI_features.h"

#ifdef __MMI_AUTO_LANG_EN__
#define MMI_DEFLANGSSC_FOR_AUTO    "*#0044#"
#endif

#define SSC_SW_VERSION             "*#8375#"
#define SSC_HW_VERSION             "*#357#" //Not used if __MMI_HW_VERSION__ is not turned on
#define SSC_ENGINEERING_MODE       "*#3646633#"
#define SSC_FACTORY_MODE           "*#66*#"
#define SSC_FACTORY_MODE_AUTOTEST  "*#87#"
#define SSC_SERIAL_NUMBER          "*#33778#"

#ifdef __MMI_FM_LCD_CONTRAST__
#define SSC_SET_LCD_CONTRAST       "*#523#"
#endif

#define SSC_IR_OPEN                "*#678#"
#define SSC_IR_CLOSE               "*#876#"
#define SSC_VENDORAPP              "*#3366*#"
#ifdef __FLAVOR_VENDOR_SDK__
#define SSC_AVKAPP                 "*#87285*#"
#endif
/* for SSC disable */
#define SSC_DISABLE_FOR_SHIPMENT   "*#6810#"

/* SML menu implementation */
#ifdef __MMI_SML_MENU__
#define SSC_SML_ADD_CODE           "###765*02#"
#define SSC_SML_REMOVE_CODE        "###765*07#"
#define SSC_SML_LOCK_CODE          "###765*05#"
#define SSC_SML_UNLOCK_CODE        "###765*08#"
#define SSC_SML_DEACTIVATE_CODE    "###765*78#" /* permanent unlock */
#define SSC_SML_LOCK_CMD           "*7525#"
#define SSC_SML_UNLOCK_CMD         "#7525#"
#define SSC_SML_QUERY_CMD          "*#7525#"
#ifdef __MMI_SML_NP_ONLY__
#define SSC_SML_UNLOCK_NP_CMD      "*#7525*01#"
#define SSC_SML_UNLOCK_NSP_CMD     "*#7525*02#"
#define SSC_SML_UNLOCK_SP_CMD      "*#7525*03#"
#define SSC_SML_UNLOCK_CP_CMD      "*#7525*04#"
#define SSC_SML_UNLOCK_SIMP_CMD    "*#7525*05#"
#define SSC_SML_UNLOCK_NS_SP_CMD   "*#7525*06#"
#define SSC_SML_UNLOCK_SIM_C_CMD   "*#7525*07#"
#endif /* __MMI_SML_NP_ONLY__ */
#endif /* __MMI_SML_MENU__ */

#if defined(__MMI_OP11_HOMESCREEN_0301__) || defined(__MMI_OP11_HOMESCREEN_0302__) || defined(__MMI_OP11_HOMESCREEN__)
#define SSC_OP11_HOMESCREEN        "*#20801#"
#endif /* __MMI_OP11_HOMESCREEN__ */

#define SSC_DISABLE_KEYPAD_LOCK_BY_END_KEY  "*#5566183#"

#define CUST_IMG_BASE_PATH			"..\\\\..\\\\Customer\\\\Images"

//MTK Leo added, to customize mmi
	#define CUS_STR_DATA_FILENAME		"..\\..\\Customer\\CustResource\\PLUTO_MMI\\CustStrRes.c" //Filename containg the array of gdi_resource_custom_string_t.
	#define CUS_STR_MAP_FILENAME		"..\\..\\Customer\\CustResource\\PLUTO_MMI\\CustStrMap.c" //Filename containg the array of gdi_resource_custom_string_map_16_t.
	#define CUS_IMG_DATA_FILENAME		"..\\..\\Customer\\CustResource\\PLUTO_MMI\\CustImgRes.c" //Filename containg the array of gdi_resource_custom_image_t.
	#define CUS_IMG_MAP_FILENAME		"..\\..\\Customer\\CustResource\\PLUTO_MMI\\CustImgMap.c" //Filename containg the array of CustDataRes.
	#define CUS_MENU_DATA_FILENAME		"..\\..\\Customer\\CustResource\\PLUTO_MMI\\CustMenuRes.c" //Filename containg the array of CUSTOM_MENU.
	#define CUS_IMG_HW_FILENAME		"..\\..\\Customer\\CustResource\\PLUTO_MMI\\CustImgDataHW.h"

  #define CUST_IMG_PATH_ROOT      "..\\\\..\\\\..\\\\..\\\\custom_resource\\\\images"
  #define CUST_IMG_PATH 		  "..\\\\..\\\\..\\\\..\\\\custom_resource\\\\images"
  #define RES_IMG_ROOT			  "..\\\\..\\\\..\\\\..\\\\custom_resource\\\\images"
  #define RES_THEME_ROOT		  "..\\\\..\\\\..\\\\..\\\\custom_resource\\\\images"


/* 20061103 SubLCD start */
#if defined(CUST_SUBLCD_PATH)
    #undef CUST_SUBLCD_PATH
#endif
#if defined(__MMI_SUBLCD_48X64BW__)
    #define CUST_SUBLCD_PATH			"..\\\\..\\\\Customer\\\\Images\\\\SubLCDBW48X64"
#elif defined(__MMI_SUBLCD_64X96__)
    #define CUST_SUBLCD_PATH			"..\\\\..\\\\Customer\\\\Images\\\\SubLCD64X96"
#elif defined(__MMI_SUBLCD_96X64BW__)
    #define CUST_SUBLCD_PATH			"..\\\\..\\\\Customer\\\\Images\\\\SubLCDBW96X64"
#elif defined(__MMI_SUBLCD_96X64__)
    #define CUST_SUBLCD_PATH			"..\\\\..\\\\Customer\\\\Images\\\\SubLCD96X64"
#elif defined(__MMI_SUBLCD_128X128__)
    #define CUST_SUBLCD_PATH			"..\\\\..\\\\Customer\\\\Images\\\\SubLCD128X128"
#endif
/* 20061103 SubLCD end */
/*101205 audio resource Calvin Satrt */
	#define CUST_ADO_PATH			"..\\\\..\\\\Customer\\\\AUDIO\\\\PLUTO"
/*101205 audio resource Calvin End */

#define CUST_BINARY_PATH			"..\\\\..\\\\Customer\\\\Binary"

#ifndef __OPTR_NONE__
#include "Operator_CustResDef.h"
#endif


#define CUST_THIRD_ROM_BIN_PATH     "..\\..\\Customer\\CustResource"

#endif


