/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
#ifndef __GUI_RESOURCE_TYPE_H__
#define __GUI_RESOURCE_TYPE_H__

#include "MMI_features.h"
#include "gdi_const.h"

/* Image Resource Types */
#define IMAGE_TYPE_INVALID                GDI_IMAGE_TYPE_INVALID
#define IMAGE_TYPE_BMP                    GDI_IMAGE_TYPE_BMP
#define IMAGE_TYPE_BMP_SEQUENCE           GDI_IMAGE_TYPE_BMP_SEQUENCE
#define IMAGE_TYPE_GIF                    GDI_IMAGE_TYPE_GIF
#define IMAGE_TYPE_DEVICE_BITMAP          GDI_IMAGE_TYPE_DEVICE_BITMAP
#define IMAGE_TYPE_DEVICE_BITMAP_SEQUENCE GDI_IMAGE_TYPE_DEVICE_BITMAP_SEQUENCE
#define IMAGE_TYPE_BMP_FILE               GDI_IMAGE_TYPE_BMP_FILE
#define IMAGE_TYPE_GIF_FILE               GDI_IMAGE_TYPE_GIF_FILE
#define IMAGE_TYPE_WBMP_FILE              GDI_IMAGE_TYPE_WBMP_FILE
#define IMAGE_TYPE_JPG                    GDI_IMAGE_TYPE_JPG
#define IMAGE_TYPE_JPG_FILE               GDI_IMAGE_TYPE_JPG_FILE
#define IMAGE_TYPE_WBMP                   GDI_IMAGE_TYPE_WBMP
#define IMAGE_TYPE_AVI                    GDI_IMAGE_TYPE_AVI
#define IMAGE_TYPE_AVI_FILE               GDI_IMAGE_TYPE_AVI_FILE
#define IMAGE_TYPE_3GP                    GDI_IMAGE_TYPE_3GP
#define IMAGE_TYPE_3GP_FILE               GDI_IMAGE_TYPE_3GP_FILE
#define IMAGE_TYPE_MP4                    GDI_IMAGE_TYPE_MP4
#define IMAGE_TYPE_MP4_FILE               GDI_IMAGE_TYPE_MP4_FILE
#define IMAGE_TYPE_JPG_SEQUENCE           GDI_IMAGE_TYPE_JPG_SEQUENCE
#ifdef __MMI_DOWNLOADABLE_THEMES_SUPPORT__
#define IMAGE_TYPE_BMP_FILE_OFFSET        GDI_IMAGE_TYPE_BMP_FILE_OFFSET
#define IMAGE_TYPE_GIF_FILE_OFFSET        GDI_IMAGE_TYPE_GIF_FILE_OFFSET
#endif /* __MMI_DOWNLOADABLE_THEMES_SUPPORT__ */
#define IMAGE_TYPE_PNG                    GDI_IMAGE_TYPE_PNG
#define IMAGE_TYPE_PNG_SEQUENCE           GDI_IMAGE_TYPE_PNG_SEQUENCE
#define IMAGE_TYPE_M3D                    GDI_IMAGE_TYPE_M3D
#define IMAGE_TYPE_SWFLASH                GDI_IMAGE_TYPE_SWFLASH
#define IMAGE_TYPE_SVG                    GDI_IMAGE_TYPE_SVG
#define IMAGE_TYPE_SVG_FILE               GDI_IMAGE_TYPE_SVG_FILE
#define IMAGE_TYPE_ABM                    GDI_IMAGE_TYPE_ABM
#define IMAGE_TYPE_ABM_SEQUENCE           GDI_IMAGE_TYPE_ABM_SEQUENCE
#define IMAGE_TYPE_ABM_FILE_OFFSET        GDI_IMAGE_TYPE_ABM_FILE_OFFSET
#define IMAGE_TYPE_VIS                    GDI_IMAGE_TYPE_VIS
#define IMAGE_TYPE_VIS_FILE               GDI_IMAGE_TYPE_VIS_FILE
#define IMAGE_TYPE_KTX                    GDI_IMAGE_TYPE_KTX
#define IMAGE_TYPE_PPN                    (GDI_IMAGE_TYPE_SUM + 1)
#define IMAGE_TYPE_TTF                    (GDI_IMAGE_TYPE_SUM + 2)
#define IMAGE_TYPE_RV                     (GDI_IMAGE_TYPE_SUM + 3)
#define IMAGE_TYPE_RV_FILE                (GDI_IMAGE_TYPE_SUM + 4)
#define IMAGE_TYPE_RM                     (GDI_IMAGE_TYPE_SUM + 5)
#define IMAGE_TYPE_RM_FILE                (GDI_IMAGE_TYPE_SUM + 6)
#define IMAGE_TYPE_RMVB                   (GDI_IMAGE_TYPE_SUM + 7)
#define IMAGE_TYPE_RMVB_FILE              (GDI_IMAGE_TYPE_SUM + 8)
#ifdef __MMI_RESOURCE_ENFB_SUPPORT__
#define IMAGE_TYPE_ENFB                   255
#endif
#define IMAGE_TYPE_AB2                    GDI_IMAGE_TYPE_AB2
#define IMAGE_TYPE_AB2_SEQUENCE           GDI_IMAGE_TYPE_AB2_SEQUENCE
#define IMAGE_TYPE_AB2_FILE_OFFSET        GDI_IMAGE_TYPE_AB2_FILE_OFFSET

#define IMAGE_TYPE_9SLICE                 GDI_IMAGE_TYPE_9SLICE

/* Audio Resource Types */
#define AUDIO_TYPE_INVALID             0
#define AUDIO_TYPE_MP3                 5
#define AUDIO_TYPE_IMY                 18
#define AUDIO_TYPE_MID                 17
#define AUDIO_TYPE_WAV                 13
#define AUDIO_TYPE_MMF                 20
#define AUDIO_TYPE_PCM                 7
#define AUDIO_TYPE_DVI                 11
#define AUDIO_TYPE_AMR                 3
#define AUDIO_TYPE_AAC                 6
#define AUDIO_TYPE_WMA                 24
#define AUDIO_TYPE_M4A                 25

#endif /* __GUI_RESOURCE_TYPE_H__ */

