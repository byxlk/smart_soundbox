Notice: 
    Starting with LinkIt SDK version 4.2.0, Easy PinMux Tool, FOTA packing tool, Resgen, MT2523 Flash Tool and MT7687 Flash Tool can be downloaded from MediaTek Labs website. 
    The tools/PC_tool.zip file will only contain MT2523 Flash Tool or MT7687 Flash Tool (Windows version). 
    MT7687/MT7697 resource download link: 
      https://docs.labs.mediatek.com/resource/mt7687-mt7697/en/downloads
    MT2523 resource download link: 
      https://docs.labs.mediatek.com/resource/mt2523/en/downloads

     
